# Zaika Royale - Native Android Application 📱
**GRILL • KARAHI • BURGERS**

This is the complete, production-ready native Android project for **Zaika Royale**, built with:
- **Language**: Kotlin 2.0
- **UI Framework**: Jetpack Compose (Material 3)
- **Minimum SDK**: Android 7.0 (API 24)
- **Target SDK**: Android 15 (API 35)
- **Architecture**: Single Activity, Compose Navigation, Repository Pattern

---

## 🚀 Options for Android Phone Users (Without a Computer)

### Option 1: Instant Install via Android Phone Browser (PWA)
1. Open the Zaika Royale app in Google Chrome or Samsung Internet on your phone.
2. Tap the **three dots menu (⋮)** in the browser.
3. Tap **"Install app"** or **"Add to Home screen"**.
4. The Zaika Royale icon will appear on your phone's app drawer and home screen. It opens full screen with splash screen and fast performance without needing any APK installation!

---

### Option 2: Generate APK in the Cloud (Free, 2 Minutes, From Phone)
This project includes an automated **GitHub Actions** build workflow:
1. Go to [GitHub.com](https://github.com) on your phone browser.
2. Create a new repository (e.g. `zaika-royale-android`).
3. Upload this extracted folder or commit the files.
4. Tap the **Actions** tab on GitHub:
   - The workflow `Build Zaika Royale Android APK` will automatically start.
   - It will compile the project using standard cloud Android SDK runners.
5. Once completed (~2 minutes), tap on the build run and download the **ZaikaRoyale-Debug-APK** artifact!
6. Rename or tap the `.apk` file to install it directly on your Android phone!

---

### Option 3: Compile on PC with Android Studio
1. Unzip `ZaikaRoyale-Android-Project.zip`.
2. Open **Android Studio** (Ladybug or Hedgehog or newer).
3. Select **File > Open** and select the `android` folder.
4. Allow Gradle to sync.
5. Go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The compiled APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Transfer this APK to your phone via USB, WhatsApp, or Google Drive and install!

---

## 📦 Project Structure

- `app/src/main/java/com/zaikaroyale/app/`
  - `MainActivity.kt` - Main Android activity with edge-to-edge support
  - `ZaikaRoyaleApp.kt` - Main composable with Bottom Navigation & Scaffold
  - `data/`
    - `model/Models.kt` - Food items, categories, deals, orders, reviews data models
    - `repository/RestaurantRepository.kt` - Reactive in-memory state repository
  - `ui/`
    - `customer/` - Customer screens (Home, Menu, Deals, Cart, Checkout, Order Tracking, Reviews)
    - `admin/` - Secure Owner/Admin panel (Dashboard, Orders, Menu CRUD, Categories, Discounts, Delivery, Reviews, Settings)
    - `navigation/Screen.kt` - Navigation routes
    - `theme/` - Red, Turquoise, Charcoal Material 3 theme palette
- `gradle/libs.versions.toml` - Gradle version catalog
- `.github/workflows/build-apk.yml` - Automated Cloud APK builder
