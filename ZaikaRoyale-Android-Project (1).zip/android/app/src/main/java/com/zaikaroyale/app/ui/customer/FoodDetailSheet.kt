package com.zaikaroyale.app.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.FoodAddon
import com.zaikaroyale.app.data.model.FoodItem
import com.zaikaroyale.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoodDetailSheet(
    item: FoodItem?,
    onDismiss: () -> Unit,
    onAddToCart: (FoodItem, Int, List<FoodAddon>, String) -> Unit
) {
    if (item == null) return

    var quantity by remember { mutableStateOf(1) }
    var selectedAddOns by remember { mutableStateOf<List<FoodAddon>>(emptyList()) }
    var specialNotes by remember { mutableStateOf("") }

    val totalItemPrice = (item.effectivePrice + selectedAddOns.sumOf { it.price }) * quantity

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            // Header with Close
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    item.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = ZaikaCharcoal,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = ZaikaSlateMedium)
                }
            }

            Text(
                item.description,
                style = MaterialTheme.typography.bodyMedium,
                color = ZaikaSlateMedium,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Price & Prep Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Rs. ${item.effectivePrice.toInt()}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = ZaikaRed
                    )
                    if (item.discountPrice != null) {
                        Text(
                            "Rs. ${item.price.toInt()}",
                            fontSize = 13.sp,
                            color = ZaikaSlateMedium,
                            textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                        )
                    }
                }

                Surface(
                    color = ZaikaSlateLight,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "⏱ ${item.preparationTime}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ZaikaSlateDark,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Addons section if available
            if (item.addOns.isNotEmpty()) {
                Text(
                    "Customize with Add-ons",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = ZaikaCharcoal
                )
                Spacer(modifier = Modifier.height(8.dp))

                item.addOns.forEach { addon ->
                    val isSelected = selectedAddOns.any { it.id == addon.id }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) ZaikaTealLight.copy(alpha = 0.5f) else ZaikaSlateLight
                        ),
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, ZaikaTeal) else null
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { checked ->
                                        selectedAddOns = if (checked) {
                                            selectedAddOns + addon
                                        } else {
                                            selectedAddOns.filter { it.id != addon.id }
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = ZaikaTeal)
                                )
                                Text(addon.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Text("+ Rs. ${addon.price.toInt()}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ZaikaTealDark)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Special notes
            OutlinedTextField(
                value = specialNotes,
                onValueChange = { specialNotes = it },
                label = { Text("Special cooking instructions (optional)") },
                placeholder = { Text("e.g. Mild spicy, extra sauce, no onions") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Quantity & Add to Cart Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Stepper
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(ZaikaSlateLight, RoundedCornerShape(12.dp))
                        .padding(4.dp)
                ) {
                    IconButton(
                        onClick = { if (quantity > 1) quantity-- },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                    }
                    Text(
                        quantity.toString(),
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                    IconButton(
                        onClick = { quantity++ },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                    }
                }

                Button(
                    onClick = {
                        onAddToCart(item, quantity, selectedAddOns, specialNotes)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).padding(start = 12.dp)
                ) {
                    Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "Add Rs. ${totalItemPrice.toInt()}",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
