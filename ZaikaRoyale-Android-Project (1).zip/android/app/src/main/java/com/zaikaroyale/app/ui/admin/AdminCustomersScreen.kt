package com.zaikaroyale.app.ui.admin

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.CustomerRecord
import com.zaikaroyale.app.ui.components.openWhatsApp
import com.zaikaroyale.app.ui.theme.*

@Composable
fun AdminCustomersScreen(
    customers: List<CustomerRecord>,
    onBack: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text("Customer Directory", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = ZaikaCharcoal)
                    Text("${customers.size} unique customers registered", fontSize = 11.sp, color = ZaikaSlateMedium)
                }
            }
        }

        items(customers) { cust ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(cust.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ZaikaCharcoal)
                        Text(cust.phone, fontSize = 11.sp, color = ZaikaSlateDark)
                        Text(cust.address, fontSize = 10.sp, color = ZaikaSlateMedium, maxLines = 1)
                        Row(modifier = Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("${cust.totalOrders} Orders", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ZaikaTealDark)
                            Text("Lifetime: Rs. ${cust.totalSpent.toInt()}", fontSize = 10.sp, fontWeight = FontWeight.Black, color = ZaikaGreen)
                        }
                    }

                    Row {
                        IconButton(onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${cust.phone}"))
                            context.startActivity(intent)
                        }) {
                            Icon(Icons.Default.Phone, contentDescription = "Call", tint = ZaikaSlateDark, modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = {
                            openWhatsApp(context, cust.phone, "Hi ${cust.name}, this is Zaika Royale Restaurant management.")
                        }) {
                            Icon(Icons.Default.Chat, contentDescription = "WhatsApp", tint = ZaikaWhatsApp, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }
}
