package com.zaikaroyale.app.ui.admin

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.PaymentAccounts
import com.zaikaroyale.app.data.model.RestaurantSettings
import com.zaikaroyale.app.ui.theme.*

@Composable
fun AdminSettingsScreen(
    settings: RestaurantSettings,
    onUpdateSettings: (RestaurantSettings) -> Unit,
    onChangePassword: (String, String) -> Pair<Boolean, String>,
    onResetDatabase: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current

    var name by remember { mutableStateOf(settings.name) }
    var phone by remember { mutableStateOf(settings.phone) }
    var whatsapp by remember { mutableStateOf(settings.whatsappNumber) }
    var address by remember { mutableStateOf(settings.address) }
    var hours by remember { mutableStateOf(settings.openingHours) }

    var bankName by remember { mutableStateOf(settings.paymentAccounts.bankName) }
    var bankTitle by remember { mutableStateOf(settings.paymentAccounts.bankTitle) }
    var bankIban by remember { mutableStateOf(settings.paymentAccounts.bankIban) }

    var epTitle by remember { mutableStateOf(settings.paymentAccounts.easypaisaTitle) }
    var epNumber by remember { mutableStateOf(settings.paymentAccounts.easypaisaNumber) }

    var jcTitle by remember { mutableStateOf(settings.paymentAccounts.jazzcashTitle) }
    var jcNumber by remember { mutableStateOf(settings.paymentAccounts.jazzcashNumber) }

    var currentPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text("Restaurant & POS Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = ZaikaCharcoal)
                    Text("Branding, contact phone, payment gateways & security", fontSize = 11.sp, color = ZaikaSlateMedium)
                }
            }
        }

        // Restaurant Info
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("1. Brand & Contact Numbers", fontWeight = FontWeight.Black, fontSize = 13.sp)

                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Restaurant Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Hotline Phone") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = whatsapp, onValueChange = { whatsapp = it }, label = { Text("WhatsApp Order Number") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Physical Address") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = hours, onValueChange = { hours = it }, label = { Text("Operating Hours") }, modifier = Modifier.fillMaxWidth())
                }
            }
        }

        // Payment Gateways Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("2. Payment Gateways (Bank, Easypaisa, JazzCash)", fontWeight = FontWeight.Black, fontSize = 13.sp)

                    Text("Bank Account Details", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = ZaikaTealDark)
                    OutlinedTextField(value = bankName, onValueChange = { bankName = it }, label = { Text("Bank Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = bankTitle, onValueChange = { bankTitle = it }, label = { Text("Account Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = bankIban, onValueChange = { bankIban = it }, label = { Text("IBAN") }, modifier = Modifier.fillMaxWidth())

                    HorizontalDivider()

                    Text("Mobile Wallets", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = ZaikaGreen)
                    OutlinedTextField(value = epTitle, onValueChange = { epTitle = it }, label = { Text("Easypaisa Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = epNumber, onValueChange = { epNumber = it }, label = { Text("Easypaisa Mobile #") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = jcTitle, onValueChange = { jcTitle = it }, label = { Text("JazzCash Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = jcNumber, onValueChange = { jcNumber = it }, label = { Text("JazzCash Mobile #") }, modifier = Modifier.fillMaxWidth())

                    Button(
                        onClick = {
                            val updated = settings.copy(
                                name = name,
                                phone = phone,
                                whatsappNumber = whatsapp,
                                address = address,
                                openingHours = hours,
                                paymentAccounts = PaymentAccounts(
                                    bankName = bankName,
                                    bankTitle = bankTitle,
                                    bankIban = bankIban,
                                    easypaisaTitle = epTitle,
                                    easypaisaNumber = epNumber,
                                    jazzcashTitle = jcTitle,
                                    jazzcashNumber = jcNumber
                                )
                            )
                            onUpdateSettings(updated)
                            Toast.makeText(context, "Settings saved successfully!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Restaurant Settings")
                    }
                }
            }
        }

        // Change Password Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("3. Change Admin Password", fontWeight = FontWeight.Black, fontSize = 13.sp)

                    OutlinedTextField(
                        value = currentPass,
                        onValueChange = { currentPass = it },
                        label = { Text("Current Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newPass,
                        onValueChange = { newPass = it },
                        label = { Text("New Password (min 6 characters)") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val (success, msg) = onChangePassword(currentPass, newPass)
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            if (success) {
                                currentPass = ""
                                newPass = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ZaikaCharcoal),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Update Security Password")
                    }
                }
            }
        }

        // Reset Demo Database
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = ZaikaRedLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Reset Database", fontWeight = FontWeight.Black, fontSize = 13.sp, color = ZaikaRedDark)
                    Text("Revert menu, test orders, and reviews back to pristine demo state.", fontSize = 11.sp, color = ZaikaRedDark)

                    Button(
                        onClick = {
                            onResetDatabase()
                            Toast.makeText(context, "Database restored to demo state!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Reset Demo Data")
                    }
                }
            }
        }
    }
}
