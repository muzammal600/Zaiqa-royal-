package com.zaikaroyale.app

import android.app.Application
import com.zaikaroyale.app.data.repository.RestaurantRepository

class ZaikaRoyaleApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize unified persistent repository
        RestaurantRepository.getInstance(this)
    }
}
