package com.zaikaroyale.app.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Review
import com.zaikaroyale.app.ui.components.RatingStars
import com.zaikaroyale.app.ui.theme.*

@Composable
fun AdminReviewsScreen(
    reviews: List<Review>,
    onUpdateStatus: (String, String) -> Unit,
    onDeleteReview: (String) -> Unit,
    onBack: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text("Customer Reviews Moderation", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = ZaikaCharcoal)
                    Text("${reviews.size} total customer reviews submitted", fontSize = 11.sp, color = ZaikaSlateMedium)
                }
            }
        }

        items(reviews) { rev ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(rev.customerName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        RatingStars(rating = rev.rating)
                    }

                    Text("\"${rev.comment}\"", fontSize = 11.sp, color = ZaikaSlateDark)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Status: ${rev.status.uppercase()}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (rev.status == "approved") ZaikaGreen else ZaikaRed)
                        Row {
                            if (rev.status != "approved") {
                                TextButton(onClick = { onUpdateStatus(rev.id, "approved") }) {
                                    Text("Approve", color = ZaikaGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            if (rev.status != "rejected") {
                                TextButton(onClick = { onUpdateStatus(rev.id, "rejected") }) {
                                    Text("Reject", color = Color(0xFFD97706), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            IconButton(onClick = { onDeleteReview(rev.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ZaikaRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
