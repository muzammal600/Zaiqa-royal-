package com.zaikaroyale.app.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.OrderStatus
import com.zaikaroyale.app.ui.navigation.Screen
import com.zaikaroyale.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerTopBar(
    onNavigateToAdmin: () -> Unit,
    onCallPhone: () -> Unit
) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(listOf(ZaikaRed, ZaikaRedDark))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🔥", fontSize = 18.sp)
                }
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "ZAIKA",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "ROYALE",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = ZaikaRed
                        )
                    }
                    Text(
                        "GRILL • KARAHI • BURGERS",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = ZaikaTeal,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        },
        actions = {
            IconButton(onClick = onCallPhone) {
                Icon(
                    Icons.Default.Phone,
                    contentDescription = "Call Hotline",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            IconButton(onClick = onNavigateToAdmin) {
                Icon(
                    Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin Panel",
                    tint = ZaikaTeal,
                    modifier = Modifier.size(24.dp)
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = ZaikaCharcoal
        )
    )
}

@Composable
fun CustomerBottomNav(
    currentRoute: String?,
    cartCount: Int,
    onNavigate: (String) -> Unit
) {
    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 8.dp
    ) {
        val items = listOf(
            NavigationItem(Screen.Home.route, "Home", Icons.Default.Home, Icons.Outlined.Home),
            NavigationItem(Screen.Menu.route, "Menu", Icons.Default.RestaurantMenu, Icons.Outlined.RestaurantMenu),
            NavigationItem(Screen.Deals.route, "Deals", Icons.Default.LocalOffer, Icons.Outlined.LocalOffer),
            NavigationItem(Screen.Cart.route, "Cart", Icons.Default.ShoppingBag, Icons.Outlined.ShoppingBag, badge = cartCount),
            NavigationItem(Screen.Track.route, "Track", Icons.Default.DeliveryDining, Icons.Outlined.DeliveryDining)
        )

        items.forEach { item ->
            val selected = currentRoute == item.route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(item.route) },
                icon = {
                    BadgedBox(
                        badge = {
                            if (item.badge > 0) {
                                Badge(
                                    containerColor = ZaikaRed,
                                    contentColor = Color.White
                                ) {
                                    Text(item.badge.toString(), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    ) {
                        Icon(
                            if (selected) item.selectedIcon else item.unselectedIcon,
                            contentDescription = item.label
                        )
                    }
                },
                label = {
                    Text(
                        item.label,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 11.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = ZaikaRed,
                    selectedTextColor = ZaikaRed,
                    unselectedIconColor = ZaikaSlateMedium,
                    unselectedTextColor = ZaikaSlateMedium,
                    indicatorColor = ZaikaRedLight
                )
            )
        }
    }
}

private data class NavigationItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val badge: Int = 0
)

@Composable
fun StickyCartBanner(
    cartCount: Int,
    totalAmount: Double,
    onClick: () -> Unit
) {
    AnimatedVisibility(
        visible = cartCount > 0,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clickable { onClick() },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = ZaikaRed),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.ShoppingBag,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        "$cartCount ${if (cartCount == 1) "item" else "items"} in Cart",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Rs. ${totalAmount.toInt()}",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            "View Cart →",
                            color = ZaikaRed,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WhatsAppFloatingButton(
    phoneNumber: String,
    message: String = "Hello Zaika Royale, I would like to place an order!"
) {
    val context = LocalContext.current
    FloatingActionButton(
        onClick = {
            openWhatsApp(context, phoneNumber, message)
        },
        containerColor = ZaikaWhatsApp,
        contentColor = Color.White,
        shape = CircleShape,
        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(Icons.Default.Chat, contentDescription = "WhatsApp Order")
            Text("WhatsApp", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

fun openWhatsApp(context: Context, phoneNumber: String, message: String) {
    try {
        val cleanPhone = phoneNumber.filter { it.isDigit() }
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        context.startActivity(intent)
    } catch (e: Exception) {
        // Fallback to normal dial or browser
        val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
        context.startActivity(dial)
    }
}

@Composable
fun StatusBadge(status: OrderStatus) {
    val (bgColor, textColor) = when (status) {
        OrderStatus.Pending -> Color(0xFFFEF3C7) to Color(0xFF92400E)
        OrderStatus.Confirmed -> Color(0xFFCFFAFE) to Color(0xFF0E7490)
        OrderStatus.Preparing -> Color(0xFFF3E8FF) to Color(0xFF6B21A8)
        OrderStatus.OutForDelivery -> Color(0xFFDBEAFE) to Color(0xFF1E40AF)
        OrderStatus.Delivered -> Color(0xFFDCFCE7) to Color(0xFF166534)
        OrderStatus.Cancelled -> Color(0xFFFEE2E2) to Color(0xFF991B1B)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(100.dp)
    ) {
        Text(
            text = status.displayName.uppercase(),
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun RatingStars(rating: Int, max: Int = 5) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        for (i in 1..max) {
            Icon(
                Icons.Default.Star,
                contentDescription = null,
                tint = if (i <= rating) GoldAccent else Color(0xFFE2E8F0),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}
