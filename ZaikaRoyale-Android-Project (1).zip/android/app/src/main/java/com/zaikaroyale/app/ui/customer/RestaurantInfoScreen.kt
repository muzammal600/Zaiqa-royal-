package com.zaikaroyale.app.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.DeliveryArea
import com.zaikaroyale.app.data.model.RestaurantSettings
import com.zaikaroyale.app.ui.components.openWhatsApp
import com.zaikaroyale.app.ui.theme.*

@Composable
fun RestaurantInfoScreen(
    settings: RestaurantSettings,
    deliveryAreas: List<DeliveryArea>
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    "Restaurant & Delivery Information",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = ZaikaCharcoal
                )
                Text("Locate Zaika Royale and view express delivery zones", fontSize = 11.sp, color = ZaikaSlateMedium)
            }
        }

        // Contact & Hours Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Zaika Royale Restaurant", fontWeight = FontWeight.Black, fontSize = 16.sp, color = ZaikaCharcoal)
                    Text(settings.tagline, fontSize = 11.sp, color = ZaikaTeal, fontWeight = FontWeight.Bold)

                    HorizontalDivider()

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = ZaikaRed, modifier = Modifier.size(20.dp))
                        Column {
                            Text("Address", fontSize = 11.sp, color = ZaikaSlateMedium)
                            Text("${settings.address}, ${settings.city}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.AccessTime, contentDescription = null, tint = ZaikaTeal, modifier = Modifier.size(20.dp))
                        Column {
                            Text("Kitchen Hours", fontSize = 11.sp, color = ZaikaSlateMedium)
                            Text(settings.openingHours, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = ZaikaSlateDark, modifier = Modifier.size(20.dp))
                        Column {
                            Text("Hotline", fontSize = 11.sp, color = ZaikaSlateMedium)
                            Text(settings.phone, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Button(
                        onClick = {
                            openWhatsApp(
                                context,
                                settings.whatsappNumber,
                                "Hello Zaika Royale, inquiring about restaurant timings & reservations."
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ZaikaWhatsApp),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Connect via WhatsApp (${settings.whatsappNumber})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Delivery Coverage Zones
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Express Delivery Coverage", fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Surface(
                            color = ZaikaTealLight,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                "Free on Rs. ${settings.freeDeliveryThreshold.toInt()}+",
                                color = ZaikaTealDark,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    deliveryAreas.forEach { area ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(area.name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("~${area.estimatedMinutes} mins", fontSize = 10.sp, color = ZaikaSlateMedium)
                            }
                            Text("Rs. ${area.charge.toInt()}", fontWeight = FontWeight.Black, fontSize = 12.sp, color = ZaikaCharcoal)
                        }
                        HorizontalDivider(color = ZaikaSlateLight)
                    }
                }
            }
        }
    }
}
