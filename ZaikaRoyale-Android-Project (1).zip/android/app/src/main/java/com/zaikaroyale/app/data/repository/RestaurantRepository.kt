package com.zaikaroyale.app.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zaikaroyale.app.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

class RestaurantRepository private constructor(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("ZAIKA_ROYALE_PREFS", Context.MODE_PRIVATE)
    private val gson = Gson()

    // Reactive StateFlows
    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    private val _foodItems = MutableStateFlow<List<FoodItem>>(emptyList())
    val foodItems: StateFlow<List<FoodItem>> = _foodItems.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _offers = MutableStateFlow<List<Offer>>(emptyList())
    val offers: StateFlow<List<Offer>> = _offers.asStateFlow()

    private val _reviews = MutableStateFlow<List<Review>>(emptyList())
    val reviews: StateFlow<List<Review>> = _reviews.asStateFlow()

    private val _deliveryAreas = MutableStateFlow<List<DeliveryArea>>(emptyList())
    val deliveryAreas: StateFlow<List<DeliveryArea>> = _deliveryAreas.asStateFlow()

    private val _settings = MutableStateFlow(RestaurantSettings())
    val settings: StateFlow<RestaurantSettings> = _settings.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _appliedOffer = MutableStateFlow<Offer?>(null)
    val appliedOffer: StateFlow<Offer?> = _appliedOffer.asStateFlow()

    private val _selectedDeliveryArea = MutableStateFlow<DeliveryArea?>(null)
    val selectedDeliveryArea: StateFlow<DeliveryArea?> = _selectedDeliveryArea.asStateFlow()

    private val _adminUser = MutableStateFlow<AdminUser?>(null)
    val adminUser: StateFlow<AdminUser?> = _adminUser.asStateFlow()

    init {
        loadOrInitializeData()
    }

    companion object {
        @Volatile
        private var instance: RestaurantRepository? = null

        fun getInstance(context: Context): RestaurantRepository {
            return instance ?: synchronized(this) {
                instance ?: RestaurantRepository(context.applicationContext).also { instance = it }
            }
        }
    }

    private fun loadOrInitializeData() {
        val hasData = prefs.getBoolean("has_initialized_v1", false)
        if (!hasData) {
            seedInitialData()
        } else {
            loadFromPrefs()
        }
    }

    private fun seedInitialData() {
        val initialCategories = listOf(
            Category("cat-burgers", "Burgers", "burgers", "Artisanal smash & grilled gourmet burgers with melted cheddar", "Beef", 1, true),
            Category("cat-bbq", "BBQ & Grills", "bbq", "Smoky charcoal char-grilled seekh kababs & malai boti", "Flame", 2, true),
            Category("cat-karahi", "Karahi & Handi", "karahi", "Fresh wok-cooked desi chicken & mutton karahi", "Utensils", 3, true),
            Category("cat-biryani", "Biryani & Pulao", "biryani", "Fragrant basmati rice dum-cooked with rich spices", "Soup", 4, true),
            Category("cat-pizza", "Pizza", "pizza", "Crispy stone-baked crust with loaded mozzarella & toppings", "Pizza", 5, true),
            Category("cat-shawarma", "Shawarma & Wraps", "shawarma", "Marinated rotisserie chicken with garlic toum in pita", "Sandwich", 6, true),
            Category("cat-fastfood", "Fast Food", "fast-food", "Crispy fried chicken, nuggets, loaded fries and wings", "Sparkles", 7, true),
            Category("cat-desi", "Desi Food & Breads", "desi-food", "Daal makhani, butter paneer, rogheni naan and kulchas", "CookingPot", 8, true),
            Category("cat-rice", "Rice Specialties", "rice", "Fried rice, afghani pulao, and spicy schezwan rice bowls", "Layers", 9, true),
            Category("cat-chinese", "Chinese & Pan-Asian", "chinese", "Chicken manchurian, chow mein, and fiery chili dry", "Salad", 10, true),
            Category("cat-drinks", "Drinks & Shakes", "drinks", "Chilled mint margaritas, fresh juices and thick shakes", "Coffee", 11, true),
            Category("cat-desserts", "Desserts", "desserts", "Hot gulab jamun, molten lava cakes and kulfi falooda", "Cake", 12, true)
        )

        val initialFood = listOf(
            FoodItem(
                id = "food-1",
                name = "Royale Double Smash Burger",
                description = "Two premium beef patties smashed crisp with double aged cheddar, caramelized onions, house truffle mayo on toasted brioche.",
                price = 950.0,
                discountPrice = 799.0,
                categoryId = "cat-burgers",
                isAvailable = true,
                isFeatured = true,
                isPopular = true,
                preparationTime = "15-20 min",
                spicyLevel = 1,
                addOns = listOf(
                    FoodAddon("ad-1", "Extra Cheddar Cheese Slice", 120.0),
                    FoodAddon("ad-2", "Crispy Beef Bacon Strip", 180.0),
                    FoodAddon("ad-3", "Seasoned French Fries Upgrade", 220.0),
                    FoodAddon("ad-4", "Smoked Jalapeno Dip", 90.0)
                )
            ),
            FoodItem(
                id = "food-2",
                name = "Charcoal BBQ Mixed Platter",
                description = "Authentic spread of 4 Chicken Malai Boti skewers, 4 Beef Seekh Kababs, 2 Bihari Tikka boti, fresh mint chutney, salad and 2 tandoori naan.",
                price = 2450.0,
                discountPrice = 2199.0,
                categoryId = "cat-bbq",
                isAvailable = true,
                isFeatured = true,
                isPopular = true,
                preparationTime = "25-30 min",
                spicyLevel = 2,
                addOns = listOf(
                    FoodAddon("ad-5", "Extra Butter Roghani Naan", 110.0),
                    FoodAddon("ad-6", "Zeera Mint Raita", 80.0),
                    FoodAddon("ad-7", "Fresh Kachumber Salad", 90.0)
                )
            ),
            FoodItem(
                id = "food-3",
                name = "Desi Chicken Karahi (Full)",
                description = "Slow-cooked fresh chicken in a traditional cast-iron wok with ripe plum tomatoes, julienned ginger, green chilies, and black pepper.",
                price = 1850.0,
                categoryId = "cat-karahi",
                isAvailable = true,
                isFeatured = true,
                isPopular = true,
                preparationTime = "30-35 min",
                spicyLevel = 2,
                addOns = listOf(
                    FoodAddon("ad-8", "Desi Ghee Tadka", 180.0),
                    FoodAddon("ad-9", "Garlic Butter Naan (2 pcs)", 200.0)
                )
            ),
            FoodItem(
                id = "food-4",
                name = "Special Dum Chicken Biryani",
                description = "Long-grain aged basmati rice steamed with marinated chicken cuts, saffron, aromatic star anise, mint leaves, served with cucumber raita.",
                price = 650.0,
                discountPrice = 550.0,
                categoryId = "cat-biryani",
                isAvailable = true,
                isFeatured = true,
                isPopular = true,
                isSpecialOffer = true,
                preparationTime = "15 min",
                spicyLevel = 2,
                addOns = listOf(
                    FoodAddon("ad-11", "Extra Chicken Piece", 220.0),
                    FoodAddon("ad-12", "Spiced Shami Kabab", 150.0)
                )
            ),
            FoodItem(
                id = "food-5",
                name = "Artisan Fajita Feast Pizza (Large 13\")",
                description = "Crisp stone-baked dough, spiced chicken chunks, bell peppers, sweet red onions, black olives, topped with melted whole milk mozzarella.",
                price = 1650.0,
                discountPrice = 1450.0,
                categoryId = "cat-pizza",
                isAvailable = true,
                isFeatured = true,
                isPopular = true,
                preparationTime = "20-25 min",
                spicyLevel = 1,
                addOns = listOf(
                    FoodAddon("ad-14", "Stuffed Cheesy Crust", 290.0),
                    FoodAddon("ad-15", "Garlic Mayo Dip Sauce", 80.0)
                )
            ),
            FoodItem(
                id = "food-6",
                name = "Gourmet Chicken Shawarma Platter",
                description = "Carved spiced chicken shawarma slices on toasted pita with authentic Lebanese garlic toum, pickled turnips, and salted french fries.",
                price = 690.0,
                discountPrice = 590.0,
                categoryId = "cat-shawarma",
                isAvailable = true,
                isPopular = true,
                preparationTime = "12-15 min",
                spicyLevel = 1
            ),
            FoodItem(
                id = "food-7",
                name = "Crispy Broast Fried Chicken (4 pcs)",
                description = "Golden pressure-fried crispy chicken with 11 secret herbs and spices. Juicy inside, crunchy outside, served with dinner roll & garlic dip.",
                price = 990.0,
                categoryId = "cat-fastfood",
                isAvailable = true,
                isPopular = true,
                preparationTime = "15-20 min",
                spicyLevel = 1
            ),
            FoodItem(
                id = "food-8",
                name = "Slow-Cooked Daal Makhani",
                description = "Whole black lentils and red kidney beans simmered overnight with butter, fresh dairy cream, and subtle fenugreek aroma.",
                price = 750.0,
                categoryId = "cat-desi",
                isAvailable = true,
                preparationTime = "15 min",
                spicyLevel = 1
            ),
            FoodItem(
                id = "food-9",
                name = "Kabuli Afghani Pulao",
                description = "Tender spiced beef shank cuts buried beneath golden basmati rice cooked in broth, topped with caramelized carrots, raisins and almonds.",
                price = 1100.0,
                categoryId = "cat-rice",
                isAvailable = true,
                isPopular = true,
                preparationTime = "20 min",
                spicyLevel = 0
            ),
            FoodItem(
                id = "food-10",
                name = "Szechuan Chicken Chili Dry with Egg Rice",
                description = "Crispy chicken strips tossed in fiery green chilies, ginger, dark soy sauce, scallions, accompanied by hot wok egg fried rice.",
                price = 1250.0,
                discountPrice = 1099.0,
                categoryId = "cat-chinese",
                isAvailable = true,
                isPopular = true,
                preparationTime = "20 min",
                spicyLevel = 3
            ),
            FoodItem(
                id = "food-11",
                name = "Fresh Mint Lemon Margarita",
                description = "Crushed ice with fresh garden mint leaves, freshly squeezed lime, Himalayan black salt, and sparkling citrus fizz.",
                price = 320.0,
                categoryId = "cat-drinks",
                isAvailable = true,
                isPopular = true,
                preparationTime = "5 min",
                spicyLevel = 0
            ),
            FoodItem(
                id = "food-12",
                name = "Molten Belgian Lava Cake & Vanilla Gelato",
                description = "Warm rich dark Belgian chocolate cake with a molten oozing center, paired with velvety Madagascar vanilla bean ice cream scoop.",
                price = 650.0,
                categoryId = "cat-desserts",
                isAvailable = true,
                isFeatured = true,
                isPopular = true,
                preparationTime = "12 min",
                spicyLevel = 0
            )
        )

        val initialOffers = listOf(
            Offer("off-1", "Royale Welcome 20% OFF", "Enjoy 20% flat discount on your online feast orders above Rs. 1500", "WELCOME20", "percentage", 20.0, 1500.0, "Limited Deal: Use WELCOME20 for 20% OFF on Rs. 1500+ orders!", true, "2026-12-31"),
            Offer("off-2", "BBQ Weekend Feast (Flat Rs. 300 Off)", "Save Rs. 300 immediately on any grill, BBQ or family karahi platters", "GRILL300", "fixed", 300.0, 2000.0, "Weekend Special: Rs. 300 OFF with code GRILL300", true, "2026-11-30"),
            Offer("off-3", "Midnight Snack (Flat Rs. 150 Off)", "Quick savings for burger and shawarma lovers", "CRAVING150", "fixed", 150.0, 800.0, "Burger & Shawarma deals active!", true, "2026-12-31")
        )

        val initialDeliveryAreas = listOf(
            DeliveryArea("area-1", "DHA Phase 1-6", 150.0, 30, true),
            DeliveryArea("area-2", "Gulberg & Main Boulevard", 120.0, 25, true),
            DeliveryArea("area-3", "Johar Town & Faisal Town", 180.0, 35, true),
            DeliveryArea("area-4", "Model Town & Garden Town", 140.0, 28, true),
            DeliveryArea("area-5", "Cantt & Cavalry Ground", 150.0, 30, true),
            DeliveryArea("area-6", "Bahria Town & Valencia", 250.0, 45, true),
            DeliveryArea("area-7", "Mall Road & Old City", 200.0, 40, true)
        )

        val initialReviews = listOf(
            Review("rev-1", "Hamza Tariq", 5, "The Chicken Karahi was exceptional! Freshly made, piping hot, and full of authentic flavor with fresh ginger. Fast delivery within 30 minutes!", "ZR-1042", "2026-10-04", "approved"),
            Review("rev-2", "Ayesha Siddiqui", 5, "Best Double Smash Burger in town hands down. Crispy crust on the beef patty and the brioche was super soft. 10/10 recommendation!", "ZR-1038", "2026-10-03", "approved"),
            Review("rev-3", "Bilal Khan", 5, "Charcoal BBQ mixed platter was tender, juicy and smoky. Malai boti melted like butter. Roghani naan was hot and fresh.", "ZR-1029", "2026-10-01", "approved"),
            Review("rev-4", "Fatima Noor", 4, "Great portion size for the Dum Biryani and raita was delicious. Will definitely be ordering again with the family.", "ZR-1015", "2026-09-29", "approved")
        )

        val initialOrders = listOf(
            Order(
                id = "ord-1042",
                orderNumber = "ZR-1042",
                customerName = "Hamza Tariq",
                customerPhone = "0302-5551234",
                deliveryAddress = "House 14-A, Street 9, Sector B, Phase 5",
                deliveryArea = "DHA Phase 1-6",
                orderNotes = "Please ring doorbell and bring extra mint chutney if possible.",
                paymentMethod = PaymentMethod.CashOnDelivery,
                items = listOf(
                    OrderItem("food-3", "Desi Chicken Karahi (Full)", 1850.0, 1, listOf(FoodAddon("ad-9", "Garlic Butter Naan (2 pcs)", 200.0)), 2050.0),
                    OrderItem("food-11", "Fresh Mint Lemon Margarita", 320.0, 2, emptyList(), 640.0)
                ),
                subtotal = 2690.0,
                deliveryCharge = 0.0,
                discountAmount = 200.0,
                promoCode = "WELCOME20",
                totalAmount = 2490.0,
                status = OrderStatus.Delivered,
                createdAt = "2026-10-04 19:40",
                estimatedDeliveryMinutes = 30
            ),
            Order(
                id = "ord-1043",
                orderNumber = "ZR-1043",
                customerName = "Zainab Rashid",
                customerPhone = "0321-9876543",
                deliveryAddress = "Apartment 402, Royale Heights, MM Alam Road",
                deliveryArea = "Gulberg & Main Boulevard",
                orderNotes = "Leave with reception if not answering.",
                paymentMethod = PaymentMethod.JazzCash,
                items = listOf(
                    OrderItem("food-1", "Royale Double Smash Burger", 799.0, 2, listOf(FoodAddon("ad-3", "Seasoned French Fries Upgrade", 220.0)), 1818.0)
                ),
                subtotal = 1818.0,
                deliveryCharge = 120.0,
                discountAmount = 0.0,
                totalAmount = 1938.0,
                status = OrderStatus.Preparing,
                createdAt = "2026-10-06 20:15",
                estimatedDeliveryMinutes = 25
            ),
            Order(
                id = "ord-1044",
                orderNumber = "ZR-1044",
                customerName = "Muhammad Umair",
                customerPhone = "0333-4447890",
                deliveryAddress = "Plot 78, Block G, Johar Town near Emporium",
                deliveryArea = "Johar Town & Faisal Town",
                orderNotes = "Make it extra spicy please!",
                paymentMethod = PaymentMethod.CashOnDelivery,
                items = listOf(
                    OrderItem("food-2", "Charcoal BBQ Mixed Platter", 2199.0, 1, listOf(FoodAddon("ad-5", "Extra Butter Roghani Naan", 110.0)), 2309.0),
                    OrderItem("food-4", "Special Dum Chicken Biryani", 550.0, 1, emptyList(), 550.0)
                ),
                subtotal = 2859.0,
                deliveryCharge = 0.0,
                discountAmount = 300.0,
                promoCode = "GRILL300",
                totalAmount = 2559.0,
                status = OrderStatus.Confirmed,
                createdAt = "2026-10-06 20:45",
                estimatedDeliveryMinutes = 35
            ),
            Order(
                id = "ord-1045",
                orderNumber = "ZR-1045",
                customerName = "Dr. Shahbaz Ali",
                customerPhone = "0300-8889911",
                deliveryAddress = "House 52, Street 3, Model Town Block C",
                deliveryArea = "Model Town & Garden Town",
                orderNotes = "Call upon arrival.",
                paymentMethod = PaymentMethod.Easypaisa,
                items = listOf(
                    OrderItem("food-5", "Artisan Fajita Feast Pizza (Large 13\")", 1450.0, 1, listOf(FoodAddon("ad-14", "Stuffed Cheesy Crust", 290.0)), 1740.0)
                ),
                subtotal = 1740.0,
                deliveryCharge = 140.0,
                discountAmount = 0.0,
                totalAmount = 1880.0,
                status = OrderStatus.Pending,
                createdAt = "2026-10-06 21:05",
                estimatedDeliveryMinutes = 28
            )
        )

        _categories.value = initialCategories
        _foodItems.value = initialFood
        _offers.value = initialOffers
        _deliveryAreas.value = initialDeliveryAreas
        _reviews.value = initialReviews
        _orders.value = initialOrders
        _settings.value = RestaurantSettings()
        _selectedDeliveryArea.value = initialDeliveryAreas.firstOrNull()

        saveToPrefs()
        prefs.edit().putBoolean("has_initialized_v1", true).apply()
    }

    private fun saveToPrefs() {
        prefs.edit()
            .putString("categories", gson.toJson(_categories.value))
            .putString("foodItems", gson.toJson(_foodItems.value))
            .putString("orders", gson.toJson(_orders.value))
            .putString("offers", gson.toJson(_offers.value))
            .putString("reviews", gson.toJson(_reviews.value))
            .putString("deliveryAreas", gson.toJson(_deliveryAreas.value))
            .putString("settings", gson.toJson(_settings.value))
            .apply()
    }

    private fun loadFromPrefs() {
        try {
            val catJson = prefs.getString("categories", null)
            if (catJson != null) {
                val type = object : TypeToken<List<Category>>() {}.type
                _categories.value = gson.fromJson(catJson, type)
            }

            val foodJson = prefs.getString("foodItems", null)
            if (foodJson != null) {
                val type = object : TypeToken<List<FoodItem>>() {}.type
                _foodItems.value = gson.fromJson(foodJson, type)
            }

            val orderJson = prefs.getString("orders", null)
            if (orderJson != null) {
                val type = object : TypeToken<List<Order>>() {}.type
                _orders.value = gson.fromJson(orderJson, type)
            }

            val offerJson = prefs.getString("offers", null)
            if (offerJson != null) {
                val type = object : TypeToken<List<Offer>>() {}.type
                _offers.value = gson.fromJson(offerJson, type)
            }

            val revJson = prefs.getString("reviews", null)
            if (revJson != null) {
                val type = object : TypeToken<List<Review>>() {}.type
                _reviews.value = gson.fromJson(revJson, type)
            }

            val areaJson = prefs.getString("deliveryAreas", null)
            if (areaJson != null) {
                val type = object : TypeToken<List<DeliveryArea>>() {}.type
                _deliveryAreas.value = gson.fromJson(areaJson, type)
                _selectedDeliveryArea.value = _deliveryAreas.value.firstOrNull()
            }

            val setJson = prefs.getString("settings", null)
            if (setJson != null) {
                _settings.value = gson.fromJson(setJson, RestaurantSettings::class.java)
            }

            // Restore admin session if any
            val adminEmail = prefs.getString("admin_session_email", null)
            if (adminEmail != null) {
                _adminUser.value = AdminUser(email = adminEmail)
            }
        } catch (e: Exception) {
            seedInitialData()
        }
    }

    // ================= CART OPERATIONS =================
    fun addToCart(foodItem: FoodItem, quantity: Int = 1, selectedAddOns: List<FoodAddon> = emptyList(), notes: String = "") {
        val current = _cart.value.toMutableList()
        val addonIds = selectedAddOns.map { it.id }.sorted().joinToString(",")
        val existingIndex = current.indexOfFirst {
            it.foodItem.id == foodItem.id && it.selectedAddOns.map { a -> a.id }.sorted().joinToString(",") == addonIds
        }

        if (existingIndex >= 0) {
            val item = current[existingIndex]
            current[existingIndex] = item.copy(quantity = item.quantity + quantity, itemNotes = if (notes.isNotBlank()) notes else item.itemNotes)
        } else {
            current.add(CartItem(foodItem, quantity, selectedAddOns, notes))
        }
        _cart.value = current
    }

    fun updateCartQuantity(index: Int, newQuantity: Int) {
        val current = _cart.value.toMutableList()
        if (index in current.indices) {
            if (newQuantity <= 0) {
                current.removeAt(index)
            } else {
                current[index] = current[index].copy(quantity = newQuantity)
            }
            _cart.value = current
        }
    }

    fun removeFromCart(index: Int) {
        val current = _cart.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _cart.value = current
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
        _appliedOffer.value = null
    }

    fun applyPromoCode(code: String): Pair<Boolean, String> {
        val trimmed = code.trim().uppercase()
        val offer = _offers.value.find { it.isActive && it.code.uppercase() == trimmed }
            ?: return Pair(false, "Invalid promo code.")

        val subtotal = getCartSubtotal()
        if (subtotal < offer.minOrderAmount) {
            return Pair(false, "Min. order amount of Rs. ${offer.minOrderAmount.toInt()} required.")
        }
        _appliedOffer.value = offer
        return Pair(true, "Promo code '${offer.code}' applied!")
    }

    fun removePromoCode() {
        _appliedOffer.value = null
    }

    fun setSelectedDeliveryArea(area: DeliveryArea) {
        _selectedDeliveryArea.value = area
    }

    fun getCartSubtotal(): Double = _cart.value.sumOf { it.totalPrice }

    fun getDeliveryCharge(): Double {
        val subtotal = getCartSubtotal()
        val threshold = _settings.value.freeDeliveryThreshold
        if (subtotal >= threshold) return 0.0
        return _selectedDeliveryArea.value?.charge ?: _settings.value.baseDeliveryFee
    }

    fun getDiscountAmount(): Double {
        val offer = _appliedOffer.value ?: return 0.0
        val subtotal = getCartSubtotal()
        if (subtotal < offer.minOrderAmount) return 0.0
        return if (offer.discountType == "percentage") {
            (subtotal * offer.discountValue) / 100.0
        } else {
            offer.discountValue
        }
    }

    fun getFinalTotal(): Double {
        val subtotal = getCartSubtotal()
        if (subtotal == 0.0) return 0.0
        val delivery = getDeliveryCharge()
        val discount = getDiscountAmount()
        return (subtotal + delivery - discount).coerceAtLeast(0.0)
    }

    // ================= CUSTOMER ORDER CREATION =================
    fun createOrder(
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        deliveryArea: String,
        orderNotes: String?,
        paymentMethod: PaymentMethod
    ): Order {
        val randomSuffix = (1000..9999).random()
        val orderNumber = "ZR-$randomSuffix"
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val dateStr = sdf.format(Date())

        val orderItems = _cart.value.map {
            OrderItem(
                foodItemId = it.foodItem.id,
                name = it.foodItem.name,
                price = it.foodItem.effectivePrice,
                quantity = it.quantity,
                selectedAddOns = it.selectedAddOns,
                subtotal = it.totalPrice,
                itemNotes = it.itemNotes.ifBlank { null }
            )
        }

        val newOrder = Order(
            id = "ord-${System.currentTimeMillis()}",
            orderNumber = orderNumber,
            customerName = customerName.trim(),
            customerPhone = customerPhone.trim(),
            deliveryAddress = deliveryAddress.trim(),
            deliveryArea = deliveryArea,
            orderNotes = orderNotes?.ifBlank { null },
            paymentMethod = paymentMethod,
            items = orderItems,
            subtotal = getCartSubtotal(),
            deliveryCharge = getDeliveryCharge(),
            discountAmount = getDiscountAmount(),
            promoCode = _appliedOffer.value?.code,
            totalAmount = getFinalTotal(),
            status = OrderStatus.Pending,
            createdAt = dateStr,
            estimatedDeliveryMinutes = _selectedDeliveryArea.value?.estimatedMinutes ?: 35
        )

        val updatedOrders = listOf(newOrder) + _orders.value
        _orders.value = updatedOrders
        saveToPrefs()
        clearCart()
        return newOrder
    }

    fun findOrder(query: String): Order? {
        val q = query.trim().lowercase()
        return _orders.value.find {
            it.orderNumber.lowercase() == q || it.customerPhone.replace("-", "").contains(q.replace("-", ""))
        }
    }

    fun addReview(customerName: String, rating: Int, comment: String, orderNumber: String?): Review {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val rev = Review(
            id = "rev-${System.currentTimeMillis()}",
            customerName = customerName.trim(),
            rating = rating,
            comment = comment.trim(),
            orderNumber = orderNumber?.ifBlank { null },
            date = sdf.format(Date()),
            status = "approved"
        )
        val updated = listOf(rev) + _reviews.value
        _reviews.value = updated
        saveToPrefs()
        return rev
    }

    // ================= ADMIN OPERATIONS =================
    fun loginAdmin(password: String, email: String = "admin@zaikaroyale.com"): Pair<Boolean, String> {
        val savedPass = prefs.getString("custom_admin_password", "admin123") ?: "admin123"
        return if (password == savedPass) {
            val user = AdminUser(email = email)
            _adminUser.value = user
            prefs.edit().putString("admin_session_email", email).apply()
            Pair(true, "Logged in as ${user.name}")
        } else {
            Pair(false, "Invalid password. Default is admin123")
        }
    }

    fun logoutAdmin() {
        _adminUser.value = null
        prefs.edit().remove("admin_session_email").apply()
    }

    fun changeAdminPassword(oldPass: String, newPass: String): Pair<Boolean, String> {
        val savedPass = prefs.getString("custom_admin_password", "admin123") ?: "admin123"
        if (oldPass != savedPass) return Pair(false, "Current password does not match.")
        if (newPass.length < 6) return Pair(false, "Password must be at least 6 characters.")
        prefs.edit().putString("custom_admin_password", newPass).apply()
        return Pair(true, "Admin password updated successfully.")
    }

    fun updateOrderStatus(orderId: String, status: OrderStatus, cancelReason: String? = null) {
        val current = _orders.value.toMutableList()
        val index = current.indexOfFirst { it.id == orderId || it.orderNumber == orderId }
        if (index >= 0) {
            current[index] = current[index].copy(status = status, cancelReason = cancelReason)
            _orders.value = current
            saveToPrefs()
        }
    }

    fun addFoodItem(item: FoodItem) {
        val updated = _foodItems.value + item.copy(id = "food-${System.currentTimeMillis()}")
        _foodItems.value = updated
        saveToPrefs()
    }

    fun updateFoodItem(item: FoodItem) {
        val current = _foodItems.value.toMutableList()
        val index = current.indexOfFirst { it.id == item.id }
        if (index >= 0) {
            current[index] = item
            _foodItems.value = current
            saveToPrefs()
        }
    }

    fun deleteFoodItem(id: String) {
        _foodItems.value = _foodItems.value.filter { it.id != id }
        saveToPrefs()
    }

    fun addCategory(category: Category) {
        val updated = _categories.value + category.copy(id = "cat-${System.currentTimeMillis()}")
        _categories.value = updated
        saveToPrefs()
    }

    fun updateCategory(category: Category) {
        val current = _categories.value.toMutableList()
        val index = current.indexOfFirst { it.id == category.id }
        if (index >= 0) {
            current[index] = category
            _categories.value = current
            saveToPrefs()
        }
    }

    fun deleteCategory(id: String) {
        _categories.value = _categories.value.filter { it.id != id }
        saveToPrefs()
    }

    fun addOffer(offer: Offer) {
        val updated = _offers.value + offer.copy(id = "off-${System.currentTimeMillis()}")
        _offers.value = updated
        saveToPrefs()
    }

    fun updateOffer(offer: Offer) {
        val current = _offers.value.toMutableList()
        val index = current.indexOfFirst { it.id == offer.id }
        if (index >= 0) {
            current[index] = offer
            _offers.value = current
            saveToPrefs()
        }
    }

    fun deleteOffer(id: String) {
        _offers.value = _offers.value.filter { it.id != id }
        saveToPrefs()
    }

    fun addDeliveryArea(area: DeliveryArea) {
        val updated = _deliveryAreas.value + area.copy(id = "area-${System.currentTimeMillis()}")
        _deliveryAreas.value = updated
        saveToPrefs()
    }

    fun updateDeliveryArea(area: DeliveryArea) {
        val current = _deliveryAreas.value.toMutableList()
        val index = current.indexOfFirst { it.id == area.id }
        if (index >= 0) {
            current[index] = area
            _deliveryAreas.value = current
            saveToPrefs()
        }
    }

    fun deleteDeliveryArea(id: String) {
        _deliveryAreas.value = _deliveryAreas.value.filter { it.id != id }
        saveToPrefs()
    }

    fun updateReviewStatus(id: String, status: String) {
        val current = _reviews.value.toMutableList()
        val index = current.indexOfFirst { it.id == id }
        if (index >= 0) {
            current[index] = current[index].copy(status = status)
            _reviews.value = current
            saveToPrefs()
        }
    }

    fun deleteReview(id: String) {
        _reviews.value = _reviews.value.filter { it.id != id }
        saveToPrefs()
    }

    fun updateSettings(newSettings: RestaurantSettings) {
        _settings.value = newSettings
        saveToPrefs()
    }

    fun resetToDefault() {
        prefs.edit().clear().apply()
        seedInitialData()
    }

    fun getCustomers(): List<CustomerRecord> {
        val map = mutableMapOf<String, CustomerRecord>()
        _orders.value.forEach { o ->
            val key = o.customerPhone.trim()
            val existing = map[key]
            if (existing != null) {
                map[key] = existing.copy(
                    totalOrders = existing.totalOrders + 1,
                    totalSpent = existing.totalSpent + if (o.status != OrderStatus.Cancelled) o.totalAmount else 0.0,
                    lastOrderDate = if (o.createdAt > existing.lastOrderDate) o.createdAt else existing.lastOrderDate
                )
            } else {
                map[key] = CustomerRecord(
                    id = "cust-${key.filter { it.isDigit() }}",
                    name = o.customerName,
                    phone = o.customerPhone,
                    address = o.deliveryAddress,
                    totalOrders = 1,
                    totalSpent = if (o.status != OrderStatus.Cancelled) o.totalAmount else 0.0,
                    lastOrderDate = o.createdAt
                )
            }
        }
        return map.values.sortedByDescending { it.totalSpent }
    }

    fun getAnalytics(): SalesAnalytics {
        val orders = _orders.value
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        val todayOrders = orders.filter { it.createdAt.startsWith(todayStr) }
        val todaySales = todayOrders.filter { it.status != OrderStatus.Cancelled }.sumOf { it.totalAmount }

        val totalOrders = orders.size
        val pendingOrders = orders.count { it.status == OrderStatus.Pending }
        val completedOrders = orders.count { it.status == OrderStatus.Delivered }
        val cancelledOrders = orders.count { it.status == OrderStatus.Cancelled }
        val totalSales = orders.filter { it.status != OrderStatus.Cancelled }.sumOf { it.totalAmount }

        val itemSales = mutableMapOf<String, Pair<Int, Double>>()
        orders.filter { it.status != OrderStatus.Cancelled }.forEach { o ->
            o.items.forEach { it ->
                val current = itemSales[it.name] ?: Pair(0, 0.0)
                itemSales[it.name] = Pair(current.first + it.quantity, current.second + it.subtotal)
            }
        }

        val bestSellers = itemSales.map { (name, pair) ->
            BestSellerItem(name, pair.first, pair.second)
        }.sortedByDescending { it.quantity }.take(5)

        return SalesAnalytics(
            todaySales = todaySales,
            todayOrdersCount = todayOrders.size,
            totalOrdersCount = totalOrders,
            pendingOrdersCount = pendingOrders,
            completedOrdersCount = completedOrders,
            cancelledOrdersCount = cancelledOrders,
            totalSales = totalSales,
            totalCustomersCount = getCustomers().size,
            bestSellers = bestSellers
        )
    }
}
