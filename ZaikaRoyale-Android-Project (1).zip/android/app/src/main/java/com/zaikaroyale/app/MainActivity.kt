package com.zaikaroyale.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.zaikaroyale.app.data.model.FoodItem
import com.zaikaroyale.app.data.repository.RestaurantRepository
import com.zaikaroyale.app.ui.components.*
import com.zaikaroyale.app.ui.customer.*
import com.zaikaroyale.app.ui.admin.*
import com.zaikaroyale.app.ui.navigation.Screen
import com.zaikaroyale.app.ui.theme.ZaikaRoyaleTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = RestaurantRepository.getInstance(this)

        setContent {
            ZaikaRoyaleTheme {
                MainAppNavHost(repository = repository, onCallHotline = { phone ->
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                    startActivity(intent)
                })
            }
        }
    }
}

@Composable
fun MainAppNavHost(
    repository: RestaurantRepository,
    onCallHotline: (String) -> Unit
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Data State Flows
    val categories by repository.categories.collectAsState()
    val foodItems by repository.foodItems.collectAsState()
    val orders by repository.orders.collectAsState()
    val offers by repository.offers.collectAsState()
    val reviews by repository.reviews.collectAsState()
    val deliveryAreas by repository.deliveryAreas.collectAsState()
    val settings by repository.settings.collectAsState()
    val cart by repository.cart.collectAsState()
    val appliedOffer by repository.appliedOffer.collectAsState()
    val selectedDeliveryArea by repository.selectedDeliveryArea.collectAsState()
    val adminUser by repository.adminUser.collectAsState()

    var selectedFoodForDetails by remember { mutableStateOf<FoodItem?>(null) }

    val isCustomerScreen = currentRoute in listOf(
        Screen.Home.route,
        Screen.Menu.route,
        Screen.Deals.route,
        Screen.Cart.route,
        Screen.Track.route
    )

    val cartCount = cart.sumOf { it.quantity }
    val cartTotal = repository.getFinalTotal()

    Scaffold(
        topBar = {
            if (isCustomerScreen) {
                CustomerTopBar(
                    onNavigateToAdmin = {
                        if (adminUser != null) {
                            navController.navigate(Screen.AdminDashboard.route)
                        } else {
                            navController.navigate(Screen.AdminLogin.route)
                        }
                    },
                    onCallPhone = { onCallHotline(settings.phone) }
                )
            }
        },
        bottomBar = {
            if (isCustomerScreen) {
                Column {
                    // Show sticky cart pill on Home and Menu if items exist
                    if (currentRoute == Screen.Home.route || currentRoute == Screen.Menu.route) {
                        StickyCartBanner(
                            cartCount = cartCount,
                            totalAmount = cartTotal,
                            onClick = { navController.navigate(Screen.Cart.route) }
                        )
                    }

                    CustomerBottomNav(
                        currentRoute = currentRoute,
                        cartCount = cartCount,
                        onNavigate = { route ->
                            navController.navigate(route) {
                                popUpTo(Screen.Home.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        },
        floatingActionButton = {
            if (currentRoute == Screen.Home.route || currentRoute == Screen.Menu.route) {
                WhatsAppFloatingButton(phoneNumber = settings.whatsappNumber)
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route
            ) {
                // ================= CUSTOMER ROUTES =================
                composable(Screen.Home.route) {
                    HomeScreen(
                        settings = settings,
                        categories = categories,
                        featuredFood = foodItems,
                        onNavigateToMenu = { navController.navigate(Screen.Menu.route) },
                        onNavigateToDeals = { navController.navigate(Screen.Deals.route) },
                        onSelectCategory = { catId ->
                            navController.navigate(Screen.Menu.route)
                        },
                        onFoodClick = { food -> selectedFoodForDetails = food },
                        onNavigateToReviews = { navController.navigate(Screen.Reviews.route) },
                        onNavigateToInfo = { navController.navigate(Screen.Info.route) }
                    )
                }

                composable(Screen.Menu.route) {
                    MenuScreen(
                        categories = categories,
                        foodItems = foodItems,
                        selectedCategoryId = null,
                        onSelectCategory = {},
                        onFoodClick = { food -> selectedFoodForDetails = food }
                    )
                }

                composable(Screen.Deals.route) {
                    DealsScreen(
                        offers = offers,
                        onApplyCode = { code -> repository.applyPromoCode(code) }
                    )
                }

                composable(Screen.Cart.route) {
                    CartScreen(
                        cart = cart,
                        subtotal = repository.getCartSubtotal(),
                        deliveryCharge = repository.getDeliveryCharge(),
                        discountAmount = repository.getDiscountAmount(),
                        finalTotal = repository.getFinalTotal(),
                        appliedOffer = appliedOffer,
                        deliveryAreas = deliveryAreas,
                        selectedArea = selectedDeliveryArea,
                        settings = settings,
                        onUpdateQuantity = { idx, qty -> repository.updateCartQuantity(idx, qty) },
                        onRemoveItem = { idx -> repository.removeFromCart(idx) },
                        onApplyPromo = { code -> repository.applyPromoCode(code) },
                        onRemovePromo = { repository.removePromoCode() },
                        onSelectArea = { area -> repository.setSelectedDeliveryArea(area) },
                        onNavigateToCheckout = { navController.navigate(Screen.Checkout.route) },
                        onNavigateToMenu = { navController.navigate(Screen.Menu.route) }
                    )
                }

                composable(Screen.Track.route) {
                    OrderTrackingScreen(
                        settings = settings,
                        onSearchOrder = { query -> repository.findOrder(query) },
                        onNavigateToHome = { navController.navigate(Screen.Home.route) }
                    )
                }

                composable(Screen.Checkout.route) {
                    CheckoutScreen(
                        cart = cart,
                        subtotal = repository.getCartSubtotal(),
                        deliveryCharge = repository.getDeliveryCharge(),
                        discountAmount = repository.getDiscountAmount(),
                        finalTotal = repository.getFinalTotal(),
                        selectedArea = selectedDeliveryArea,
                        settings = settings,
                        onPlaceOrder = { name, phone, address, area, notes, payment ->
                            val order = repository.createOrder(name, phone, address, area, notes, payment)
                            navController.navigate(Screen.OrderConfirmation.createRoute(order.id)) {
                                popUpTo(Screen.Cart.route) { inclusive = true }
                            }
                        },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = Screen.OrderConfirmation.route,
                    arguments = listOf(navArgument("orderId") { type = NavType.StringType })
                ) { backStack ->
                    val orderId = backStack.arguments?.getString("orderId") ?: ""
                    val order = orders.find { it.id == orderId } ?: orders.firstOrNull()
                    if (order != null) {
                        OrderConfirmationScreen(
                            order = order,
                            settings = settings,
                            onTrackOrder = { orderNo ->
                                navController.navigate(Screen.Track.route)
                            },
                            onBackToHome = {
                                navController.navigate(Screen.Home.route) {
                                    popUpTo(Screen.Home.route) { inclusive = true }
                                }
                            }
                        )
                    }
                }

                composable(Screen.Reviews.route) {
                    ReviewsScreen(
                        reviews = reviews,
                        onAddReview = { name, rating, comment, orderNo ->
                            repository.addReview(name, rating, comment, orderNo)
                        }
                    )
                }

                composable(Screen.Info.route) {
                    RestaurantInfoScreen(
                        settings = settings,
                        deliveryAreas = deliveryAreas
                    )
                }

                // ================= ADMIN ROUTES =================
                composable(Screen.AdminLogin.route) {
                    AdminLoginScreen(
                        onLogin = { pass, email -> repository.loginAdmin(pass, email) },
                        onLoginSuccess = {
                            navController.navigate(Screen.AdminDashboard.route) {
                                popUpTo(Screen.AdminLogin.route) { inclusive = true }
                            }
                        },
                        onBackToCustomer = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminDashboard.route) {
                    BackHandler {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Home.route) { inclusive = true }
                        }
                    }

                    AdminDashboardScreen(
                        analytics = repository.getAnalytics(),
                        orders = orders,
                        onNavigateToOrders = { navController.navigate(Screen.AdminOrders.route) },
                        onNavigateToMenu = { navController.navigate(Screen.AdminMenu.route) },
                        onNavigateToCategories = { navController.navigate(Screen.AdminCategories.route) },
                        onNavigateToOffers = { navController.navigate(Screen.AdminOffers.route) },
                        onNavigateToCustomers = { navController.navigate(Screen.AdminCustomers.route) },
                        onNavigateToDelivery = { navController.navigate(Screen.AdminDelivery.route) },
                        onNavigateToReviews = { navController.navigate(Screen.AdminReviews.route) },
                        onNavigateToSettings = { navController.navigate(Screen.AdminSettings.route) },
                        onUpdateOrderStatus = { id, st -> repository.updateOrderStatus(id, st) }
                    )
                }

                composable(Screen.AdminOrders.route) {
                    AdminOrdersScreen(
                        orders = orders,
                        onUpdateStatus = { id, status, reason -> repository.updateOrderStatus(id, status, reason) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminMenu.route) {
                    AdminMenuScreen(
                        foodItems = foodItems,
                        categories = categories,
                        onAddFood = { item -> repository.addFoodItem(item) },
                        onUpdateFood = { item -> repository.updateFoodItem(item) },
                        onDeleteFood = { id -> repository.deleteFoodItem(id) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminCategories.route) {
                    AdminCategoriesScreen(
                        categories = categories,
                        onAddCategory = { cat -> repository.addCategory(cat) },
                        onUpdateCategory = { cat -> repository.updateCategory(cat) },
                        onDeleteCategory = { id -> repository.deleteCategory(id) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminOffers.route) {
                    AdminOffersScreen(
                        offers = offers,
                        onAddOffer = { off -> repository.addOffer(off) },
                        onUpdateOffer = { off -> repository.updateOffer(off) },
                        onDeleteOffer = { id -> repository.deleteOffer(id) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminCustomers.route) {
                    AdminCustomersScreen(
                        customers = repository.getCustomers(),
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminDelivery.route) {
                    AdminDeliveryScreen(
                        deliveryAreas = deliveryAreas,
                        settings = settings,
                        onUpdateSettings = { s -> repository.updateSettings(s) },
                        onAddArea = { a -> repository.addDeliveryArea(a) },
                        onDeleteArea = { id -> repository.deleteDeliveryArea(id) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminReviews.route) {
                    AdminReviewsScreen(
                        reviews = reviews,
                        onUpdateStatus = { id, st -> repository.updateReviewStatus(id, st) },
                        onDeleteReview = { id -> repository.deleteReview(id) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminSettings.route) {
                    AdminSettingsScreen(
                        settings = settings,
                        onUpdateSettings = { s -> repository.updateSettings(s) },
                        onChangePassword = { oldP, newP -> repository.changeAdminPassword(oldP, newP) },
                        onResetDatabase = { repository.resetToDefault() },
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }

    // Modal sheet for food detail customization
    selectedFoodForDetails?.let { food ->
        FoodDetailSheet(
            item = food,
            onDismiss = { selectedFoodForDetails = null },
            onAddToCart = { item, qty, addons, notes ->
                repository.addToCart(item, qty, addons, notes)
                selectedFoodForDetails = null
            }
        )
    }
}
