package com.zaikaroyale.app.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.CartItem
import com.zaikaroyale.app.data.model.DeliveryArea
import com.zaikaroyale.app.data.model.Offer
import com.zaikaroyale.app.data.model.RestaurantSettings
import com.zaikaroyale.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    cart: List<CartItem>,
    subtotal: Double,
    deliveryCharge: Double,
    discountAmount: Double,
    finalTotal: Double,
    appliedOffer: Offer?,
    deliveryAreas: List<DeliveryArea>,
    selectedArea: DeliveryArea?,
    settings: RestaurantSettings,
    onUpdateQuantity: (Int, Int) -> Unit,
    onRemoveItem: (Int) -> Unit,
    onApplyPromo: (String) -> Pair<Boolean, String>,
    onRemovePromo: () -> Unit,
    onSelectArea: (DeliveryArea) -> Unit,
    onNavigateToCheckout: () -> Unit,
    onNavigateToMenu: () -> Unit
) {
    var promoInput by remember { mutableStateOf("") }
    var promoStatusMessage by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    var areaMenuExpanded by remember { mutableStateOf(false) }

    val freeThreshold = settings.freeDeliveryThreshold
    val remainingForFreeDelivery = (freeThreshold - subtotal).coerceAtLeast(0.0)
    val freeDeliveryProgress = (subtotal / freeThreshold).toFloat().coerceIn(0f, 1f)

    if (cart.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ZaikaBgLight)
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🛍️", fontSize = 64.sp)
                Spacer(modifier = Modifier.height(16.dp))
                Text("Your Cart is Empty", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text(
                    "Discover our sizzling BBQ, Chicken Karahi and burgers to start your order.",
                    fontSize = 12.sp,
                    color = ZaikaSlateMedium,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                )
                Button(
                    onClick = onNavigateToMenu,
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Browse Food Menu", fontWeight = FontWeight.Bold)
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Free Delivery Progress Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ZaikaTealLight)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    if (remainingForFreeDelivery > 0) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Add Rs. ${remainingForFreeDelivery.toInt()} more for Free Delivery",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ZaikaTealDark
                            )
                            Text(
                                "${(freeDeliveryProgress * 100).toInt()}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = ZaikaTealDark
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { freeDeliveryProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp),
                            color = ZaikaTeal,
                            trackColor = Color.White
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ZaikaGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Congratulations! You qualify for Free Delivery",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ZaikaGreen
                            )
                        }
                    }
                }
            }
        }

        // Cart Items List
        itemsIndexed(cart) { index, item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                item.foodItem.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = ZaikaCharcoal,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { onRemoveItem(index) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = ZaikaSlateMedium, modifier = Modifier.size(16.dp))
                            }
                        }

                        if (item.selectedAddOns.isNotEmpty()) {
                            Text(
                                "+ " + item.selectedAddOns.joinToString(", ") { it.name },
                                fontSize = 11.sp,
                                color = ZaikaTeal,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        if (item.itemNotes.isNotBlank()) {
                            Text(
                                "Note: \"${item.itemNotes}\"",
                                fontSize = 10.sp,
                                color = ZaikaSlateMedium,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Rs. ${item.totalPrice.toInt()}",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = ZaikaCharcoal
                            )

                            // Quantity Stepper
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .background(ZaikaSlateLight, RoundedCornerShape(8.dp))
                                    .padding(2.dp)
                            ) {
                                IconButton(
                                    onClick = { onUpdateQuantity(index, item.quantity - 1) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(14.dp))
                                }
                                Text(
                                    item.quantity.toString(),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                                IconButton(
                                    onClick = { onUpdateQuantity(index, item.quantity + 1) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Delivery Area Selection
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "Delivery Destination",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = ZaikaSlateMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    ExposedDropdownMenuBox(
                        expanded = areaMenuExpanded,
                        onExpandedChange = { areaMenuExpanded = !areaMenuExpanded }
                    ) {
                        OutlinedTextField(
                            value = "${selectedArea?.name ?: "Select Area"} (Rs. ${if (subtotal >= freeThreshold) 0 else selectedArea?.charge?.toInt() ?: 150})",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = areaMenuExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = areaMenuExpanded,
                            onDismissRequest = { areaMenuExpanded = false }
                        ) {
                            deliveryAreas.forEach { area ->
                                DropdownMenuItem(
                                    text = { Text("${area.name} — Rs. ${area.charge.toInt()} (~${area.estimatedMinutes} mins)") },
                                    onClick = {
                                        onSelectArea(area)
                                        areaMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Promo Code Box
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    if (appliedOffer != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ZaikaGreen)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    "Code ${appliedOffer.code} Applied (-Rs. ${discountAmount.toInt()})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = ZaikaGreen
                                )
                            }
                            TextButton(onClick = onRemovePromo) {
                                Text("Remove", color = ZaikaRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = promoInput,
                                onValueChange = { promoInput = it.uppercase() },
                                placeholder = { Text("Promo Code (e.g. WELCOME20)") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                            Button(
                                onClick = {
                                    if (promoInput.isNotBlank()) {
                                        promoStatusMessage = onApplyPromo(promoInput)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ZaikaCharcoal),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Apply", fontWeight = FontWeight.Bold)
                            }
                        }

                        promoStatusMessage?.let { (success, msg) ->
                            Text(
                                msg,
                                color = if (success) ZaikaGreen else ZaikaRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Bill Summary
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Order Summary", fontWeight = FontWeight.Black, fontSize = 13.sp, color = ZaikaCharcoal)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Subtotal", fontSize = 12.sp, color = ZaikaSlateMedium)
                        Text("Rs. ${subtotal.toInt()}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Delivery Fee", fontSize = 12.sp, color = ZaikaSlateMedium)
                        Text(
                            if (deliveryCharge == 0.0) "FREE" else "Rs. ${deliveryCharge.toInt()}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (deliveryCharge == 0.0) ZaikaGreen else ZaikaCharcoal
                        )
                    }

                    if (discountAmount > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Discount", fontSize = 12.sp, color = ZaikaRed)
                            Text("- Rs. ${discountAmount.toInt()}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ZaikaRed)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Grand Total", fontWeight = FontWeight.Black, fontSize = 15.sp, color = ZaikaCharcoal)
                        Text("Rs. ${finalTotal.toInt()}", fontWeight = FontWeight.Black, fontSize = 16.sp, color = ZaikaRed)
                    }
                }
            }
        }

        // Checkout Button
        item {
            Button(
                onClick = onNavigateToCheckout,
                colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text("Proceed to Checkout (Rs. ${finalTotal.toInt()})", fontWeight = FontWeight.Black, fontSize = 14.sp)
            }
        }
    }
}
