package com.zaikaroyale.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = ZaikaRed,
    onPrimary = ZaikaSurface,
    primaryContainer = ZaikaRedLight,
    onPrimaryContainer = ZaikaRedDark,

    secondary = ZaikaTeal,
    onSecondary = ZaikaSurface,
    secondaryContainer = ZaikaTealLight,
    onSecondaryContainer = ZaikaTealDark,

    tertiary = ZaikaGreen,
    onTertiary = ZaikaSurface,

    background = ZaikaBgLight,
    onBackground = ZaikaCharcoal,
    surface = ZaikaSurface,
    onSurface = ZaikaCharcoal,
    surfaceVariant = ZaikaSlateLight,
    onSurfaceVariant = ZaikaSlateDark
)

@Composable
fun ZaikaRoyaleTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = ZaikaCharcoal.toArgb()
                window.navigationBarColor = ZaikaSurface.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = true
            }
        }
    }

    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
