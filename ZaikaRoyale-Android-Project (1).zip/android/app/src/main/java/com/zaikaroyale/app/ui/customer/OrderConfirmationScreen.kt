package com.zaikaroyale.app.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Order
import com.zaikaroyale.app.data.model.OrderStatus
import com.zaikaroyale.app.data.model.RestaurantSettings
import com.zaikaroyale.app.ui.components.openWhatsApp
import com.zaikaroyale.app.ui.theme.*

@Composable
fun OrderConfirmationScreen(
    order: Order,
    settings: RestaurantSettings,
    onTrackOrder: (String) -> Unit,
    onBackToHome: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Success Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF059669), Color(0xFF0D9488))
                            )
                        )
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            color = Color.White.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(100.dp),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            "Order Confirmed!",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Text(
                            "Thank you, ${order.customerName}! Your order has been sent to the kitchen.",
                            fontSize = 12.sp,
                            color = Color(0xFFD1FAE5),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(100.dp)
                        ) {
                            Text(
                                "ORDER #${order.orderNumber}",
                                color = Color(0xFF047857),
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Status Stepper Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Kitchen Progress", fontWeight = FontWeight.Black, fontSize = 13.sp, color = ZaikaCharcoal)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val steps = listOf("Pending", "Confirmed", "Preparing", "Out for Delivery", "Delivered")
                        val currentIdx = when (order.status) {
                            OrderStatus.Pending -> 0
                            OrderStatus.Confirmed -> 1
                            OrderStatus.Preparing -> 2
                            OrderStatus.OutForDelivery -> 3
                            OrderStatus.Delivered -> 4
                            OrderStatus.Cancelled -> -1
                        }

                        steps.forEachIndexed { idx, label ->
                            val isDone = currentIdx >= idx
                            val isCurrent = currentIdx == idx

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .background(
                                            if (isCurrent) ZaikaRed else if (isDone) ZaikaTeal else ZaikaSlateLight,
                                            RoundedCornerShape(9.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isDone) {
                                        Text("✓", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Text(
                                    label,
                                    fontSize = 8.sp,
                                    fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Medium,
                                    color = if (isCurrent) ZaikaRed else if (isDone) ZaikaCharcoal else ZaikaSlateMedium,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    maxLines = 2,
                                    lineHeight = 10.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Details Breakdown Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Order Details", fontWeight = FontWeight.Black, fontSize = 13.sp)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Destination Area:", fontSize = 12.sp, color = ZaikaSlateMedium)
                        Text(order.deliveryArea, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Address:", fontSize = 12.sp, color = ZaikaSlateMedium)
                        Text(order.deliveryAddress, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Payment:", fontSize = 12.sp, color = ZaikaSlateMedium)
                        Text(order.paymentMethod.displayName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    order.items.forEach { item ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${item.quantity}x ${item.name}", fontSize = 12.sp)
                            Text("Rs. ${item.subtotal.toInt()}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Amount Due", fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Text("Rs. ${order.totalAmount.toInt()}", fontWeight = FontWeight.Black, fontSize = 15.sp, color = ZaikaRed)
                    }
                }
            }
        }

        // Action Buttons
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { onTrackOrder(order.orderNumber) },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.DeliveryDining, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Track Live Order Progress", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Button(
                    onClick = {
                        val msg = "Hi Zaika Royale, I just placed order #${order.orderNumber} for Rs. ${order.totalAmount.toInt()}! Name: ${order.customerName}."
                        openWhatsApp(context, settings.whatsappNumber, msg)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaWhatsApp),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Send Receipt on WhatsApp", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = onBackToHome,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Back to Home", fontWeight = FontWeight.Bold, color = ZaikaSlateDark)
                }
            }
        }
    }
}
