package com.zaikaroyale.app.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.DeliveryArea
import com.zaikaroyale.app.data.model.RestaurantSettings
import com.zaikaroyale.app.ui.theme.*

@Composable
fun AdminDeliveryScreen(
    deliveryAreas: List<DeliveryArea>,
    settings: RestaurantSettings,
    onUpdateSettings: (RestaurantSettings) -> Unit,
    onAddArea: (DeliveryArea) -> Unit,
    onDeleteArea: (String) -> Unit,
    onBack: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var baseFee by remember { mutableStateOf(settings.baseDeliveryFee.toInt().toString()) }
    var freeLimit by remember { mutableStateOf(settings.freeDeliveryThreshold.toInt().toString()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text("Delivery Zones & Charges", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = ZaikaCharcoal)
                    Text("Manage base fees, free delivery limits and sector rates", fontSize = 11.sp, color = ZaikaSlateMedium)
                }
            }
        }

        // Global Thresholds
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Global Delivery Policies", fontWeight = FontWeight.Black, fontSize = 13.sp)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = baseFee,
                            onValueChange = { baseFee = it },
                            label = { Text("Base Delivery Fee (Rs.)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = freeLimit,
                            onValueChange = { freeLimit = it },
                            label = { Text("Free Delivery On (Rs.)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Button(
                        onClick = {
                            val fee = baseFee.toDoubleOrNull() ?: settings.baseDeliveryFee
                            val limit = freeLimit.toDoubleOrNull() ?: settings.freeDeliveryThreshold
                            onUpdateSettings(settings.copy(baseDeliveryFee = fee, freeDeliveryThreshold = limit))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ZaikaCharcoal),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Delivery Policies")
                    }
                }
            }
        }

        // Sector List Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Specific Delivery Sectors", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Button(
                    onClick = { showDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Area", fontSize = 11.sp)
                }
            }
        }

        items(deliveryAreas) { area ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(area.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Est. time: ~${area.estimatedMinutes} mins", fontSize = 11.sp, color = ZaikaSlateMedium)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Rs. ${area.charge.toInt()}", fontWeight = FontWeight.Black, fontSize = 13.sp, color = ZaikaRed)
                        IconButton(onClick = { onDeleteArea(area.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ZaikaSlateMedium)
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        var name by remember { mutableStateOf("") }
        var charge by remember { mutableStateOf("150") }
        var minutes by remember { mutableStateOf("30") }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Add Delivery Sector", fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Sector Name (e.g. DHA Phase 8)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = charge, onValueChange = { charge = it }, label = { Text("Charge (Rs.)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = minutes, onValueChange = { minutes = it }, label = { Text("Est. Minutes") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onAddArea(
                                DeliveryArea(
                                    id = "area-${System.currentTimeMillis()}",
                                    name = name,
                                    charge = charge.toDoubleOrNull() ?: 150.0,
                                    estimatedMinutes = minutes.toIntOrNull() ?: 30,
                                    isActive = true
                                )
                            )
                            showDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed)
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancel") }
            }
        )
    }
}
