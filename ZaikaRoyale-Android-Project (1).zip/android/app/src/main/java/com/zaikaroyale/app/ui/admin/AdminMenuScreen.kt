package com.zaikaroyale.app.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Category
import com.zaikaroyale.app.data.model.FoodItem
import com.zaikaroyale.app.ui.theme.*

@Composable
fun AdminMenuScreen(
    foodItems: List<FoodItem>,
    categories: List<Category>,
    onAddFood: (FoodItem) -> Unit,
    onUpdateFood: (FoodItem) -> Unit,
    onDeleteFood: (String) -> Unit,
    onBack: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<FoodItem?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text("Food Menu Items", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = ZaikaCharcoal)
                        Text("${foodItems.size} dishes in restaurant catalog", fontSize = 11.sp, color = ZaikaSlateMedium)
                    }
                }

                Button(
                    onClick = {
                        editingItem = null
                        showDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Dish", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        items(foodItems) { item ->
            val cat = categories.find { it.id == item.categoryId }
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(item.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ZaikaCharcoal)
                            if (!item.isAvailable) {
                                Surface(color = ZaikaRedLight, shape = RoundedCornerShape(4.dp)) {
                                    Text("SOLD OUT", color = ZaikaRedDark, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                }
                            }
                        }

                        Text("Category: ${cat?.name ?: "Unknown"}", fontSize = 11.sp, color = ZaikaTeal, fontWeight = FontWeight.SemiBold)
                        Text(item.description, fontSize = 11.sp, color = ZaikaSlateMedium, maxLines = 1)

                        Row(modifier = Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Rs. ${item.effectivePrice.toInt()}", fontWeight = FontWeight.Black, fontSize = 13.sp, color = ZaikaRed)
                            if (item.discountPrice != null) {
                                Text("Regular: Rs. ${item.price.toInt()}", fontSize = 11.sp, color = ZaikaSlateMedium)
                            }
                        }
                    }

                    Row {
                        IconButton(onClick = {
                            editingItem = item
                            showDialog = true
                        }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = ZaikaTeal, modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = { onDeleteFood(item.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ZaikaRed, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        FoodItemEditorDialog(
            item = editingItem,
            categories = categories,
            onDismiss = { showDialog = false },
            onSave = { saved ->
                if (editingItem == null) {
                    onAddFood(saved)
                } else {
                    onUpdateFood(saved)
                }
                showDialog = false
            }
        )
    }
}

@Composable
fun FoodItemEditorDialog(
    item: FoodItem?,
    categories: List<Category>,
    onDismiss: () -> Unit,
    onSave: (FoodItem) -> Unit
) {
    var name by remember { mutableStateOf(item?.name ?: "") }
    var description by remember { mutableStateOf(item?.description ?: "") }
    var price by remember { mutableStateOf(item?.price?.toInt()?.toString() ?: "500") }
    var discountPrice by remember { mutableStateOf(item?.discountPrice?.toInt()?.toString() ?: "") }
    var categoryId by remember { mutableStateOf(item?.categoryId ?: categories.firstOrNull()?.id ?: "") }
    var prepTime by remember { mutableStateOf(item?.preparationTime ?: "20 min") }
    var isAvailable by remember { mutableStateOf(item?.isAvailable ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (item == null) "Add Food Item" else "Edit Food Item", fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Food Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = price,
                        onValueChange = { price = it },
                        label = { Text("Price (Rs.) *") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = discountPrice,
                        onValueChange = { discountPrice = it },
                        label = { Text("Discount (Rs.)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = prepTime,
                    onValueChange = { prepTime = it },
                    label = { Text("Prep Time") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isAvailable, onCheckedChange = { isAvailable = it })
                    Text("In Stock & Available for Ordering", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val parsedPrice = price.toDoubleOrNull() ?: 500.0
                        val parsedDiscount = discountPrice.toDoubleOrNull()
                        val newItem = item?.copy(
                            name = name.trim(),
                            description = description.trim(),
                            price = parsedPrice,
                            discountPrice = parsedDiscount,
                            categoryId = categoryId,
                            preparationTime = prepTime,
                            isAvailable = isAvailable
                        ) ?: FoodItem(
                            id = "",
                            name = name.trim(),
                            description = description.trim(),
                            price = parsedPrice,
                            discountPrice = parsedDiscount,
                            categoryId = categoryId,
                            preparationTime = prepTime,
                            isAvailable = isAvailable
                        )
                        onSave(newItem)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed)
            ) {
                Text("Save Dish")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
