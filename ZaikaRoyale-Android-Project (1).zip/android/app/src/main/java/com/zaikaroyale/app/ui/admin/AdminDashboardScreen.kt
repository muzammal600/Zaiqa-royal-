package com.zaikaroyale.app.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Order
import com.zaikaroyale.app.data.model.OrderStatus
import com.zaikaroyale.app.data.model.SalesAnalytics
import com.zaikaroyale.app.ui.components.StatusBadge
import com.zaikaroyale.app.ui.theme.*

@Composable
fun AdminDashboardScreen(
    analytics: SalesAnalytics,
    orders: List<Order>,
    onNavigateToOrders: () -> Unit,
    onNavigateToMenu: () -> Unit,
    onNavigateToCategories: () -> Unit,
    onNavigateToOffers: () -> Unit,
    onNavigateToCustomers: () -> Unit,
    onNavigateToDelivery: () -> Unit,
    onNavigateToReviews: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onUpdateOrderStatus: (String, OrderStatus) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Executive Kitchen Dashboard",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = ZaikaCharcoal
            )
            Text("Real-time revenue, order queue, and performance analytics", fontSize = 11.sp, color = ZaikaSlateMedium)
        }

        // Pending Orders Attention Banner
        if (analytics.pendingOrdersCount > 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onNavigateToOrders() },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                "🚨 ${analytics.pendingOrdersCount} New Orders Need Confirmation!",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = Color(0xFF92400E)
                            )
                            Text("Tap to review and dispatch to kitchen", fontSize = 11.sp, color = Color(0xFFB45309))
                        }
                        Text("View →", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF92400E))
                    }
                }
            }
        }

        // 7 Key Performance Metrics Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Today's Sales", "Rs. ${analytics.todaySales.toInt()}", ZaikaGreen, Modifier.weight(1f))
                    StatCard("Today's Orders", "${analytics.todayOrdersCount}", ZaikaRed, Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Pending", "${analytics.pendingOrdersCount}", Color(0xFFD97706), Modifier.weight(1f))
                    StatCard("Completed", "${analytics.completedOrdersCount}", ZaikaTeal, Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Total Lifetime Orders", "${analytics.totalOrdersCount}", ZaikaSlateDark, Modifier.weight(1f))
                    StatCard("Customers Directory", "${analytics.totalCustomersCount}", PurpleAccent, Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Cancelled Orders", "${analytics.cancelledOrdersCount}", Color(0xFFDC2626), Modifier.weight(1f))
                    StatCard("Total Revenue", "Rs. ${analytics.totalSales.toInt()}", ZaikaGreen, Modifier.weight(1f))
                }
            }
        }

        // Quick Navigation to Management Modules
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Management Modules", fontWeight = FontWeight.Black, fontSize = 13.sp)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NavModuleButton("Orders", Icons.Default.ShoppingBag, Modifier.weight(1f), onNavigateToOrders)
                        NavModuleButton("Food Menu", Icons.Default.RestaurantMenu, Modifier.weight(1f), onNavigateToMenu)
                        NavModuleButton("Categories", Icons.Default.Category, Modifier.weight(1f), onNavigateToCategories)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NavModuleButton("Deals", Icons.Default.LocalOffer, Modifier.weight(1f), onNavigateToOffers)
                        NavModuleButton("Customers", Icons.Default.People, Modifier.weight(1f), onNavigateToCustomers)
                        NavModuleButton("Delivery", Icons.Default.DeliveryDining, Modifier.weight(1f), onNavigateToDelivery)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NavModuleButton("Reviews", Icons.Default.Star, Modifier.weight(1f), onNavigateToReviews)
                        NavModuleButton("Settings", Icons.Default.Settings, Modifier.weight(1f), onNavigateToSettings)
                    }
                }
            }
        }

        // Top 5 Best Sellers
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Best Selling Food Items", fontWeight = FontWeight.Black, fontSize = 13.sp)

                    analytics.bestSellers.forEachIndexed { i, it ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${i + 1}. ${it.name}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = ZaikaCharcoal)
                            Text("${it.quantity} portions (Rs. ${it.revenue.toInt()})", fontSize = 11.sp, color = ZaikaTealDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Recent Orders Table
        item {
            Text("Recent Customer Orders", fontWeight = FontWeight.Black, fontSize = 14.sp)
        }

        items(orders.take(5)) { order ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(order.orderNumber, fontWeight = FontWeight.Black, fontSize = 13.sp, color = ZaikaCharcoal)
                        StatusBadge(status = order.status)
                    }

                    Text("${order.customerName} (${order.customerPhone})", fontSize = 11.sp, color = ZaikaSlateDark)
                    Text("Total: Rs. ${order.totalAmount.toInt()} • ${order.paymentMethod.displayName}", fontSize = 11.sp, fontWeight = FontWeight.Bold)

                    if (order.status == OrderStatus.Pending) {
                        Button(
                            onClick = { onUpdateOrderStatus(order.id, OrderStatus.Confirmed) },
                            colors = ButtonDefaults.buttonColors(containerColor = ZaikaTeal),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Confirm & Accept Order", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(label, fontSize = 10.sp, color = ZaikaSlateMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.Black, fontSize = 16.sp, color = color)
        }
    }
}

@Composable
private fun NavModuleButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = ZaikaSlateLight,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = ZaikaSlateDark, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ZaikaSlateDark)
        }
    }
}
