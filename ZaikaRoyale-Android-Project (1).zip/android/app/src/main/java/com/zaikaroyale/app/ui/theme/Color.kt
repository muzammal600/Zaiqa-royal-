package com.zaikaroyale.app.ui.theme

import androidx.compose.ui.graphics.Color

// Zaika Royale Signature Palette
val ZaikaRed = Color(0xFFDC2626)
val ZaikaRedDark = Color(0xFFB91C1C)
val ZaikaRedLight = Color(0xFFFEE2E2)

val ZaikaTeal = Color(0xFF0891B2)
val ZaikaTealDark = Color(0xFF0E7490)
val ZaikaTealLight = Color(0xFFCFFAFE)

val ZaikaGreen = Color(0xFF16A34A)
val ZaikaWhatsApp = Color(0xFF25D366)

val ZaikaCharcoal = Color(0xFF0F172A)
val ZaikaSlateDark = Color(0xFF1E293B)
val ZaikaSlateMedium = Color(0xFF64748B)
val ZaikaSlateLight = Color(0xFFF1F5F9)
val ZaikaBgLight = Color(0xFFF8FAFC)
val ZaikaSurface = Color(0xFFFFFFFF)

val GoldAccent = Color(0xFFF59E0B)
val PurpleAccent = Color(0xFF8B5CF6)
