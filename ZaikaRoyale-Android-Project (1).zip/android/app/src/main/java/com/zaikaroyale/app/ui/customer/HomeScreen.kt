package com.zaikaroyale.app.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Category
import com.zaikaroyale.app.data.model.FoodItem
import com.zaikaroyale.app.data.model.RestaurantSettings
import com.zaikaroyale.app.ui.components.RatingStars
import com.zaikaroyale.app.ui.components.openWhatsApp
import com.zaikaroyale.app.ui.theme.*

@Composable
fun HomeScreen(
    settings: RestaurantSettings,
    categories: List<Category>,
    featuredFood: List<FoodItem>,
    onNavigateToMenu: () -> Unit,
    onNavigateToDeals: () -> Unit,
    onSelectCategory: (String) -> Unit,
    onFoodClick: (FoodItem) -> Unit,
    onNavigateToReviews: () -> Unit,
    onNavigateToInfo: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // HERO SECTION
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(ZaikaCharcoal, ZaikaSlateDark)
                        )
                    )
                    .padding(20.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Kitchen status pill
                    Surface(
                        color = Color.White.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(100.dp),
                        modifier = Modifier.padding(bottom = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(ZaikaGreen, RoundedCornerShape(4.dp))
                            )
                            Text(
                                "KITCHEN OPEN NOW",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Text(
                        "Savor Exceptional Flavors & Artisanal Sizzle",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        lineHeight = 30.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        "Flame-grilled BBQ, signature smash burgers, stone-baked pizzas, and wok-fresh chicken karahi delivered piping hot to your doorstep.",
                        fontSize = 13.sp,
                        color = Color(0xFFCBD5E1),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Action Buttons: Order Now & Deals
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onNavigateToMenu,
                            colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.RestaurantMenu, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Order Now", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        Button(
                            onClick = onNavigateToDeals,
                            colors = ButtonDefaults.buttonColors(containerColor = ZaikaTeal),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.LocalOffer, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Special Deals", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // WhatsApp Order Button
                    OutlinedButton(
                        onClick = {
                            openWhatsApp(
                                context,
                                settings.whatsappNumber,
                                "Hello Zaika Royale, I would like to place an order from your Android app!"
                            )
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ZaikaWhatsApp),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, tint = ZaikaWhatsApp, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Order via WhatsApp", fontWeight = FontWeight.Bold, color = ZaikaWhatsApp, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Trust indicators
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TrustBadge(icon = "⏱", label = "30-45 Min", sub = "Fast Delivery")
                        TrustBadge(icon = "★", label = "4.9 / 5 Rating", sub = "1,200+ Reviews")
                        TrustBadge(icon = "✓", label = "100% Halal", sub = "Fresh Meat")
                    }
                }
            }
        }

        // FOOD CATEGORIES SECTION
        item {
            Column(modifier = Modifier.padding(top = 20.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Explore Categories",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = ZaikaCharcoal
                    )
                    Text(
                        "View All →",
                        color = ZaikaRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onNavigateToMenu() }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(categories.filter { it.isActive }) { cat ->
                        CategoryPill(category = cat, onClick = { onSelectCategory(cat.id) })
                    }
                }
            }
        }

        // SIGNATURE DISHES
        item {
            Column(modifier = Modifier.padding(top = 24.dp, start = 16.dp, end = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Chef's Signature Dishes",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = ZaikaCharcoal
                        )
                        Text(
                            "Freshly prepared flame grills & karahi handis",
                            fontSize = 11.sp,
                            color = ZaikaSlateMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        items(featuredFood.take(6)) { item ->
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                HomeFoodCard(item = item, onClick = { onFoodClick(item) })
            }
        }

        // REVIEWS & LOCATION CALLOUTS
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToReviews() },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RatingStars(rating = 5)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("5.0", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Text(
                                "\"Best Karahi & Double Smash Burger in town!\"",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                color = ZaikaCharcoal
                            )
                            Text("See what 1,200+ foodies say →", fontSize = 11.sp, color = ZaikaTeal, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToInfo() },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = ZaikaRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Gulberg III, Lahore", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Text("Open Daily 12:00 PM – 02:00 AM", fontSize = 11.sp, color = ZaikaSlateMedium)
                            Text("Check delivery zones & charges →", fontSize = 11.sp, color = ZaikaTeal, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrustBadge(icon: String, label: String, sub: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 16.sp, color = ZaikaTealLight)
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text(sub, color = Color(0xFF94A3B8), fontSize = 9.sp)
    }
}

@Composable
private fun CategoryPill(category: Category, onClick: () -> Unit) {
    Card(
        modifier = Modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val emoji = when (category.slug) {
                "burgers" -> "🍔"
                "bbq" -> "🔥"
                "karahi" -> "🥘"
                "biryani" -> "🍚"
                "pizza" -> "🍕"
                "shawarma" -> "🌯"
                "fast-food" -> "🍗"
                "desi-food" -> "🫓"
                "rice" -> "🍛"
                "chinese" -> "🥢"
                "drinks" -> "🍹"
                "desserts" -> "🍰"
                else -> "🍽️"
            }
            Text(emoji, fontSize = 16.sp)
            Text(
                category.name,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = ZaikaCharcoal
            )
        }
    }
}

@Composable
fun HomeFoodCard(item: FoodItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Food visual thumbnail with emoji/icon fallback
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(ZaikaSlateLight),
                contentAlignment = Alignment.Center
            ) {
                val emoji = when {
                    item.categoryId.contains("burger") -> "🍔"
                    item.categoryId.contains("bbq") -> "🍖"
                    item.categoryId.contains("karahi") -> "🥘"
                    item.categoryId.contains("biryani") -> "🍚"
                    item.categoryId.contains("pizza") -> "🍕"
                    item.categoryId.contains("shawarma") -> "🌯"
                    item.categoryId.contains("drink") -> "🍹"
                    item.categoryId.contains("dessert") -> "🍰"
                    else -> "🍽️"
                }
                Text(emoji, fontSize = 38.sp)
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    item.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = ZaikaCharcoal,
                    maxLines = 1
                )
                Text(
                    item.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZaikaSlateMedium,
                    maxLines = 2,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "Rs. ${item.effectivePrice.toInt()}",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = ZaikaRed
                        )
                        if (item.discountPrice != null) {
                            Text(
                                "Rs. ${item.price.toInt()}",
                                fontSize = 11.sp,
                                color = ZaikaSlateMedium,
                                textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                            )
                        }
                    }

                    Button(
                        onClick = onClick,
                        colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Add +", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
