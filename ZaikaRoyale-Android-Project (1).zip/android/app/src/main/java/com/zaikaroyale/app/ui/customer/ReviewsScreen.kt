package com.zaikaroyale.app.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Review
import com.zaikaroyale.app.ui.components.RatingStars
import com.zaikaroyale.app.ui.theme.*

@Composable
fun ReviewsScreen(
    reviews: List<Review>,
    onAddReview: (String, Int, String, String?) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    val approvedReviews = reviews.filter { it.status == "approved" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Customer Reviews",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = ZaikaCharcoal
                    )
                    Text("Real ratings from Zaika Royale patrons", fontSize = 11.sp, color = ZaikaSlateMedium)
                }

                Button(
                    onClick = { showDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Write Review", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Summary Rating Banner
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("4.9", fontWeight = FontWeight.Black, fontSize = 32.sp, color = ZaikaCharcoal)
                        RatingStars(rating = 5)
                        Text("Overall Score", fontSize = 10.sp, color = ZaikaSlateMedium, modifier = Modifier.padding(top = 2.dp))
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("1,200+", fontWeight = FontWeight.Black, fontSize = 22.sp, color = ZaikaTeal)
                        Text("Total Orders Reviewed", fontSize = 10.sp, color = ZaikaSlateMedium)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("98%", fontWeight = FontWeight.Black, fontSize = 22.sp, color = ZaikaGreen)
                        Text("Positive Feedback", fontSize = 10.sp, color = ZaikaSlateMedium)
                    }
                }
            }
        }

        items(approvedReviews) { rev ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(rev.customerName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ZaikaCharcoal)
                        RatingStars(rating = rev.rating)
                    }

                    Text(
                        "\"${rev.comment}\"",
                        fontSize = 12.sp,
                        color = ZaikaSlateDark,
                        lineHeight = 16.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(rev.date, fontSize = 10.sp, color = ZaikaSlateMedium)
                        if (rev.orderNumber != null) {
                            Text("Verified Order: ${rev.orderNumber}", fontSize = 10.sp, color = ZaikaTeal, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        var nameInput by remember { mutableStateOf("") }
        var commentInput by remember { mutableStateOf("") }
        var orderNoInput by remember { mutableStateOf("") }
        var ratingInput by remember { mutableStateOf(5) }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Write a Review", fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Your Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = orderNoInput,
                        onValueChange = { orderNoInput = it },
                        label = { Text("Order Number (Optional)") },
                        placeholder = { Text("e.g. ZR-1042") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Rating: ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        for (i in 1..5) {
                            Icon(
                                Icons.Default.Star,
                                contentDescription = null,
                                tint = if (i <= ratingInput) GoldAccent else Color(0xFFCBD5E1),
                                modifier = Modifier
                                    .size(24.dp)
                                    .clickable { ratingInput = i }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = commentInput,
                        onValueChange = { commentInput = it },
                        label = { Text("Your Feedback") },
                        placeholder = { Text("Tell us about food taste, delivery, temperature...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameInput.isNotBlank() && commentInput.isNotBlank()) {
                            onAddReview(nameInput, ratingInput, commentInput, orderNoInput.ifBlank { null })
                            showDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed)
                ) {
                    Text("Submit Review")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
