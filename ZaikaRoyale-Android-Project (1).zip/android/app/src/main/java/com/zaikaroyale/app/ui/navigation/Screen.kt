package com.zaikaroyale.app.ui.navigation

sealed class Screen(val route: String) {
    // Customer Bottom Nav destinations
    object Home : Screen("home")
    object Menu : Screen("menu")
    object Deals : Screen("deals")
    object Cart : Screen("cart")
    object Track : Screen("track")

    // Other customer screens
    object Checkout : Screen("checkout")
    object OrderConfirmation : Screen("order_confirmation/{orderId}") {
        fun createRoute(orderId: String) = "order_confirmation/$orderId"
    }
    object Reviews : Screen("reviews")
    object Info : Screen("info")

    // Admin screens
    object AdminLogin : Screen("admin_login")
    object AdminDashboard : Screen("admin_dashboard")
    object AdminOrders : Screen("admin_orders")
    object AdminMenu : Screen("admin_menu")
    object AdminCategories : Screen("admin_categories")
    object AdminOffers : Screen("admin_offers")
    object AdminCustomers : Screen("admin_customers")
    object AdminDelivery : Screen("admin_delivery")
    object AdminReviews : Screen("admin_reviews")
    object AdminSettings : Screen("admin_settings")
}
