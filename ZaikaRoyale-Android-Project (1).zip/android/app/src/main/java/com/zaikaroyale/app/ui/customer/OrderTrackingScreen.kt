package com.zaikaroyale.app.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Order
import com.zaikaroyale.app.data.model.OrderStatus
import com.zaikaroyale.app.data.model.RestaurantSettings
import com.zaikaroyale.app.ui.components.StatusBadge
import com.zaikaroyale.app.ui.components.openWhatsApp
import com.zaikaroyale.app.ui.theme.*

@Composable
fun OrderTrackingScreen(
    initialOrderNumber: String? = null,
    settings: RestaurantSettings,
    onSearchOrder: (String) -> Order?,
    onNavigateToHome: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf(initialOrderNumber ?: "") }
    var currentOrder by remember { mutableStateOf(initialOrderNumber?.let { onSearchOrder(it) }) }
    var searched by remember { mutableStateOf(initialOrderNumber != null) }

    LaunchedEffect(initialOrderNumber) {
        if (!initialOrderNumber.isNullOrBlank()) {
            searchQuery = initialOrderNumber
            currentOrder = onSearchOrder(initialOrderNumber)
            searched = true
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Search Header
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Track Your Food Order",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = ZaikaCharcoal
                    )
                    Text("Enter your Order # (e.g. ZR-1042) or mobile number", fontSize = 11.sp, color = ZaikaSlateMedium)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("e.g. ZR-1042 or 0300...") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (searchQuery.isNotBlank()) {
                                    currentOrder = onSearchOrder(searchQuery.trim())
                                    searched = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Track", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Demo suggestions
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("Demo orders:", fontSize = 10.sp, color = ZaikaSlateMedium)
                        listOf("ZR-1044", "ZR-1043", "ZR-1042").forEach { demoNo ->
                            Surface(
                                color = ZaikaSlateLight,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.padding(horizontal = 2.dp)
                            ) {
                                Text(
                                    demoNo,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ZaikaTeal,
                                    modifier = Modifier
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                        .background(Color.Transparent)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Search Results
        if (currentOrder != null) {
            val order = currentOrder!!

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "ORDER #${order.orderNumber}",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = ZaikaCharcoal
                                )
                                Text(
                                    "Placed at: ${order.createdAt}",
                                    fontSize = 11.sp,
                                    color = ZaikaSlateMedium
                                )
                            }
                            StatusBadge(status = order.status)
                        }

                        HorizontalDivider()

                        // Progress Timeline
                        Text("Live Kitchen Pipeline", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                        val steps = listOf(
                            Triple(OrderStatus.Pending, "Order Placed", "Waiting for kitchen acceptance"),
                            Triple(OrderStatus.Confirmed, "Confirmed", "Order verified by kitchen team"),
                            Triple(OrderStatus.Preparing, "Preparing", "Food is sizzling on grills & woks"),
                            Triple(OrderStatus.OutForDelivery, "Out for Delivery", "Rider dispatched with thermal bag"),
                            Triple(OrderStatus.Delivered, "Delivered", "Delivered hot to your address")
                        )

                        val currentIdx = when (order.status) {
                            OrderStatus.Pending -> 0
                            OrderStatus.Confirmed -> 1
                            OrderStatus.Preparing -> 2
                            OrderStatus.OutForDelivery -> 3
                            OrderStatus.Delivered -> 4
                            OrderStatus.Cancelled -> -1
                        }

                        if (order.status == OrderStatus.Cancelled) {
                            Surface(
                                color = ZaikaRedLight,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Order Cancelled", fontWeight = FontWeight.Black, color = ZaikaRedDark, fontSize = 13.sp)
                                    Text(order.cancelReason ?: "Cancelled by restaurant or customer request.", fontSize = 11.sp, color = ZaikaRedDark)
                                }
                            }
                        } else {
                            steps.forEachIndexed { idx, (status, title, subtitle) ->
                                val isDone = currentIdx >= idx
                                val isCurrent = currentIdx == idx

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .background(
                                                if (isCurrent) ZaikaRed else if (isDone) ZaikaTeal else ZaikaSlateLight,
                                                RoundedCornerShape(12.dp)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isDone) {
                                            Text("✓", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            title,
                                            fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = if (isCurrent) ZaikaRed else if (isDone) ZaikaCharcoal else ZaikaSlateMedium
                                        )
                                        Text(
                                            subtitle,
                                            fontSize = 10.sp,
                                            color = if (isCurrent) ZaikaCharcoal else ZaikaSlateMedium
                                        )
                                    }
                                }
                            }
                        }

                        HorizontalDivider()

                        // Delivery & Items
                        Text("Delivery Information", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Customer: ${order.customerName} (${order.customerPhone})", fontSize = 11.sp, color = ZaikaSlateDark)
                        Text("Address: ${order.deliveryAddress}, ${order.deliveryArea}", fontSize = 11.sp, color = ZaikaSlateDark)
                        if (order.orderNotes != null) {
                            Text("Note: \"${order.orderNotes}\"", fontSize = 11.sp, color = ZaikaSlateMedium, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                        }

                        HorizontalDivider()

                        // Items
                        order.items.forEach { item ->
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${item.quantity}x ${item.name}", fontSize = 12.sp)
                                Text("Rs. ${item.subtotal.toInt()}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Bill (${order.paymentMethod.displayName})", fontWeight = FontWeight.Black, fontSize = 13.sp)
                            Text("Rs. ${order.totalAmount.toInt()}", fontWeight = FontWeight.Black, fontSize = 14.sp, color = ZaikaRed)
                        }

                        Button(
                            onClick = {
                                openWhatsApp(
                                    context,
                                    settings.whatsappNumber,
                                    "Hi Zaika Royale, inquiring about Order #${order.orderNumber} for ${order.customerName}."
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ZaikaWhatsApp),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chat with Restaurant on WhatsApp", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        } else if (searched) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🔍", fontSize = 42.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Order Not Found", fontWeight = FontWeight.Black, fontSize = 14.sp, color = ZaikaCharcoal)
                        Text(
                            "Please check the order number or mobile number entered.",
                            fontSize = 11.sp,
                            color = ZaikaSlateMedium,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
