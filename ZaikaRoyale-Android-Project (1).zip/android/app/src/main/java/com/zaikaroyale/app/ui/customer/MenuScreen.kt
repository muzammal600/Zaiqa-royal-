package com.zaikaroyale.app.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Category
import com.zaikaroyale.app.data.model.FoodItem
import com.zaikaroyale.app.ui.theme.*

@Composable
fun MenuScreen(
    categories: List<Category>,
    foodItems: List<FoodItem>,
    selectedCategoryId: String?,
    onSelectCategory: (String?) -> Unit,
    onFoodClick: (FoodItem) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredItems = foodItems.filter { item ->
        val matchesCategory = selectedCategoryId == null || selectedCategoryId == "all" || item.categoryId == selectedCategoryId
        val matchesSearch = searchQuery.isBlank() ||
                item.name.contains(searchQuery, ignoreCase = true) ||
                item.description.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Search Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(16.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search burgers, karahi, BBQ...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ZaikaSlateMedium) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ZaikaTeal,
                        unfocusedBorderColor = ZaikaSlateLight
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Category scrollable pills
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedCategoryId == null || selectedCategoryId == "all",
                            onClick = { onSelectCategory("all") },
                            label = { Text("All Dishes", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ZaikaRed,
                                selectedLabelColor = Color.White
                            )
                        )
                    }

                    items(categories.filter { it.isActive }) { cat ->
                        FilterChip(
                            selected = selectedCategoryId == cat.id,
                            onClick = { onSelectCategory(cat.id) },
                            label = { Text(cat.name, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ZaikaTeal,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // Section title
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val catTitle = if (selectedCategoryId == null || selectedCategoryId == "all") {
                    "All Dishes"
                } else {
                    categories.find { it.id == selectedCategoryId }?.name ?: "Dishes"
                }
                Text(
                    catTitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = ZaikaCharcoal
                )
                Text(
                    "${filteredItems.size} items",
                    fontSize = 12.sp,
                    color = ZaikaSlateMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Food Items
        if (filteredItems.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🍽️", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No matching dishes found", fontWeight = FontWeight.Bold, color = ZaikaCharcoal)
                        Text("Try searching another keyword or reset filter", fontSize = 12.sp, color = ZaikaSlateMedium)
                    }
                }
            }
        } else {
            items(filteredItems) { item ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    HomeFoodCard(item = item, onClick = { onFoodClick(item) })
                }
            }
        }
    }
}
