package com.zaikaroyale.app.data.model

import com.google.gson.annotations.SerializedName

enum class OrderStatus {
    @SerializedName("Pending") Pending,
    @SerializedName("Confirmed") Confirmed,
    @SerializedName("Preparing") Preparing,
    @SerializedName("Out for Delivery") OutForDelivery,
    @SerializedName("Delivered") Delivered,
    @SerializedName("Cancelled") Cancelled;

    val displayName: String
        get() = when (this) {
            Pending -> "Pending"
            Confirmed -> "Confirmed"
            Preparing -> "Preparing"
            OutForDelivery -> "Out for Delivery"
            Delivered -> "Delivered"
            Cancelled -> "Cancelled"
        }
}

enum class PaymentMethod {
    @SerializedName("Cash on Delivery") CashOnDelivery,
    @SerializedName("Bank Transfer") BankTransfer,
    @SerializedName("Easypaisa") Easypaisa,
    @SerializedName("JazzCash") JazzCash;

    val displayName: String
        get() = when (this) {
            CashOnDelivery -> "Cash on Delivery"
            BankTransfer -> "Bank Transfer"
            Easypaisa -> "Easypaisa"
            JazzCash -> "JazzCash"
        }
}

data class FoodAddon(
    val id: String,
    val name: String,
    val price: Double
)

data class Category(
    val id: String,
    val name: String,
    val slug: String,
    val description: String,
    val iconName: String = "Utensils",
    val displayOrder: Int = 1,
    val isActive: Boolean = true
)

data class FoodItem(
    val id: String,
    val name: String,
    val description: String,
    val price: Double,
    val discountPrice: Double? = null,
    val categoryId: String,
    val image: String = "",
    val isAvailable: Boolean = true,
    val isFeatured: Boolean = false,
    val isPopular: Boolean = false,
    val isSpecialOffer: Boolean = false,
    val preparationTime: String = "20 min",
    val spicyLevel: Int = 1, // 0 none, 1 mild, 2 medium, 3 fiery
    val addOns: List<FoodAddon> = emptyList()
) {
    val effectivePrice: Double
        get() = discountPrice ?: price
}

data class CartItem(
    val foodItem: FoodItem,
    var quantity: Int = 1,
    val selectedAddOns: List<FoodAddon> = emptyList(),
    val itemNotes: String = ""
) {
    val unitPrice: Double
        get() = foodItem.effectivePrice + selectedAddOns.sumOf { it.price }

    val totalPrice: Double
        get() = unitPrice * quantity
}

data class OrderItem(
    val foodItemId: String,
    val name: String,
    val price: Double,
    val quantity: Int,
    val selectedAddOns: List<FoodAddon> = emptyList(),
    val subtotal: Double,
    val itemNotes: String? = null
)

data class Order(
    val id: String,
    val orderNumber: String,
    val customerName: String,
    val customerPhone: String,
    val deliveryAddress: String,
    val deliveryArea: String,
    val orderNotes: String? = null,
    val paymentMethod: PaymentMethod = PaymentMethod.CashOnDelivery,
    val items: List<OrderItem> = emptyList(),
    val subtotal: Double = 0.0,
    val deliveryCharge: Double = 0.0,
    val discountAmount: Double = 0.0,
    val promoCode: String? = null,
    val totalAmount: Double = 0.0,
    val status: OrderStatus = OrderStatus.Pending,
    val createdAt: String = "",
    val estimatedDeliveryMinutes: Int = 35,
    val cancelReason: String? = null
)

data class CustomerRecord(
    val id: String,
    val name: String,
    val phone: String,
    val address: String,
    val totalOrders: Int = 0,
    val totalSpent: Double = 0.0,
    val lastOrderDate: String = ""
)

data class Offer(
    val id: String,
    val title: String,
    val description: String,
    val code: String,
    val discountType: String = "percentage", // "percentage" or "fixed"
    val discountValue: Double = 20.0,
    val minOrderAmount: Double = 1500.0,
    val bannerText: String? = null,
    val isActive: Boolean = true,
    val validUntil: String = "2026-12-31"
)

data class Review(
    val id: String,
    val customerName: String,
    val rating: Int = 5,
    val comment: String,
    val orderNumber: String? = null,
    val date: String = "",
    val status: String = "approved" // "approved", "pending", "rejected"
)

data class DeliveryArea(
    val id: String,
    val name: String,
    val charge: Double = 150.0,
    val estimatedMinutes: Int = 30,
    val isActive: Boolean = true
)

data class PaymentAccounts(
    val bankTitle: String = "Zaika Royale Gourmet Foods Pvt Ltd",
    val bankName: String = "Meezan Bank Limited",
    val bankIban: String = "PK89MEZN0001234567890123",
    val easypaisaTitle: String = "Zaika Royale Kitchen",
    val easypaisaNumber: String = "0300-1234567",
    val jazzcashTitle: String = "Zaika Royale Kitchen",
    val jazzcashNumber: String = "0300-1234567"
)

data class RestaurantSettings(
    val name: String = "Zaika Royale",
    val tagline: String = "GRILL • KARAHI • BURGERS",
    val phone: String = "+92 300 1234567",
    val whatsappNumber: String = "+923001234567",
    val email: String = "orders@zaikaroyale.com",
    val address: String = "Plot 42-B, Main Boulevard, Gulberg III",
    val city: String = "Lahore, Pakistan",
    val openingHours: String = "12:00 PM – 02:00 AM Daily",
    val baseDeliveryFee: Double = 150.0,
    val freeDeliveryThreshold: Double = 2000.0,
    val currency: String = "Rs.",
    val paymentAccounts: PaymentAccounts = PaymentAccounts()
)

data class AdminUser(
    val id: String = "admin-1",
    val name: String = "Executive Owner",
    val email: String = "admin@zaikaroyale.com",
    val role: String = "Owner",
    val lastLogin: String = ""
)

data class SalesAnalytics(
    val todaySales: Double = 0.0,
    val todayOrdersCount: Int = 0,
    val totalOrdersCount: Int = 0,
    val pendingOrdersCount: Int = 0,
    val completedOrdersCount: Int = 0,
    val cancelledOrdersCount: Int = 0,
    val totalSales: Double = 0.0,
    val totalCustomersCount: Int = 0,
    val bestSellers: List<BestSellerItem> = emptyList()
)

data class BestSellerItem(
    val name: String,
    val quantity: Int,
    val revenue: Double
)
