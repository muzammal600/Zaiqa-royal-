package com.zaikaroyale.app.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.*
import com.zaikaroyale.app.ui.theme.*

@Composable
fun CheckoutScreen(
    cart: List<CartItem>,
    subtotal: Double,
    deliveryCharge: Double,
    discountAmount: Double,
    finalTotal: Double,
    selectedArea: DeliveryArea?,
    settings: RestaurantSettings,
    onPlaceOrder: (String, String, String, String, String?, PaymentMethod) -> Unit,
    onBack: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var orderNotes by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.CashOnDelivery) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var isPlacing by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Back Header
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        "Express Checkout",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = ZaikaCharcoal
                    )
                    Text("Complete delivery details to receive fresh food", fontSize = 11.sp, color = ZaikaSlateMedium)
                }
            }
        }

        if (errorMsg != null) {
            item {
                Surface(
                    color = ZaikaRedLight,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        errorMsg!!,
                        color = ZaikaRedDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // Customer & Delivery Address Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = ZaikaRed, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("1. Customer & Address", fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Full Name *") },
                        placeholder = { Text("e.g. Hamza Tariq") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Mobile / WhatsApp Number *") },
                        placeholder = { Text("e.g. 0300 1234567") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Surface(
                        color = ZaikaSlateLight,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Delivery Area:", fontSize = 12.sp, color = ZaikaSlateMedium)
                            Text(
                                selectedArea?.name ?: "Lahore Region",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = ZaikaCharcoal
                            )
                        }
                    }

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Complete Street / House Address *") },
                        placeholder = { Text("e.g. House 14-A, Street 9, Phase 5") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = orderNotes,
                        onValueChange = { orderNotes = it },
                        label = { Text("Order Notes / Instructions (Optional)") },
                        placeholder = { Text("e.g. Ring bell, deliver on 2nd floor, extra raita") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 2
                    )
                }
            }
        }

        // Payment Method Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Payment, contentDescription = null, tint = ZaikaTeal, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("2. Payment Method", fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }

                    PaymentOptionRow(
                        title = "Cash on Delivery",
                        desc = "Pay with cash when rider arrives at your door",
                        selected = paymentMethod == PaymentMethod.CashOnDelivery,
                        onSelect = { paymentMethod = PaymentMethod.CashOnDelivery }
                    )

                    PaymentOptionRow(
                        title = "Easypaisa",
                        desc = "Direct mobile account payment",
                        selected = paymentMethod == PaymentMethod.Easypaisa,
                        onSelect = { paymentMethod = PaymentMethod.Easypaisa }
                    )

                    PaymentOptionRow(
                        title = "JazzCash",
                        desc = "Fast mobile wallet payment",
                        selected = paymentMethod == PaymentMethod.JazzCash,
                        onSelect = { paymentMethod = PaymentMethod.JazzCash }
                    )

                    PaymentOptionRow(
                        title = "Bank Transfer",
                        desc = "Online IBAN / Raast payment",
                        selected = paymentMethod == PaymentMethod.BankTransfer,
                        onSelect = { paymentMethod = PaymentMethod.BankTransfer }
                    )

                    // Account Details Accordion
                    if (paymentMethod != PaymentMethod.CashOnDelivery) {
                        Surface(
                            color = ZaikaSlateLight,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Payment Account Instructions:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = ZaikaCharcoal)
                                when (paymentMethod) {
                                    PaymentMethod.Easypaisa -> {
                                        Text("Title: ${settings.paymentAccounts.easypaisaTitle}", fontSize = 11.sp)
                                        Text("Number: ${settings.paymentAccounts.easypaisaNumber}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = ZaikaGreen)
                                    }
                                    PaymentMethod.JazzCash -> {
                                        Text("Title: ${settings.paymentAccounts.jazzcashTitle}", fontSize = 11.sp)
                                        Text("Number: ${settings.paymentAccounts.jazzcashNumber}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = GoldAccent)
                                    }
                                    PaymentMethod.BankTransfer -> {
                                        Text("Bank: ${settings.paymentAccounts.bankName}", fontSize = 11.sp)
                                        Text("Title: ${settings.paymentAccounts.bankTitle}", fontSize = 11.sp)
                                        Text("IBAN: ${settings.paymentAccounts.bankIban}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                    else -> {}
                                }
                                Text(
                                    "* Please keep the transfer screenshot ready for rider verification.",
                                    fontSize = 10.sp,
                                    color = ZaikaSlateMedium
                                )
                            }
                        }
                    }
                }
            }
        }

        // Order Summary Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("3. Order Summary (${cart.sumOf { it.quantity }} items)", fontWeight = FontWeight.Black, fontSize = 13.sp)

                    cart.forEach { item ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${item.quantity}x ${item.foodItem.name}", fontSize = 12.sp, color = ZaikaSlateDark)
                            Text("Rs. ${item.totalPrice.toInt()}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Subtotal", fontSize = 12.sp, color = ZaikaSlateMedium)
                        Text("Rs. ${subtotal.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Delivery Fee", fontSize = 12.sp, color = ZaikaSlateMedium)
                        Text(if (deliveryCharge == 0.0) "FREE" else "Rs. ${deliveryCharge.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    if (discountAmount > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Discount", fontSize = 12.sp, color = ZaikaRed)
                            Text("- Rs. ${discountAmount.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ZaikaRed)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Final Total", fontWeight = FontWeight.Black, fontSize = 15.sp)
                        Text("Rs. ${finalTotal.toInt()}", fontWeight = FontWeight.Black, fontSize = 16.sp, color = ZaikaRed)
                    }
                }
            }
        }

        // Place Order Button
        item {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMsg = "Please enter your full name."
                        return@Button
                    }
                    if (phone.isBlank() || phone.length < 8) {
                        errorMsg = "Please enter a valid mobile number."
                        return@Button
                    }
                    if (address.isBlank()) {
                        errorMsg = "Please specify your complete delivery address."
                        return@Button
                    }
                    errorMsg = null
                    isPlacing = true
                    onPlaceOrder(
                        name,
                        phone,
                        address,
                        selectedArea?.name ?: "Lahore Region",
                        orderNotes,
                        paymentMethod
                    )
                },
                enabled = !isPlacing,
                colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                if (isPlacing) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Confirm & Place Order (Rs. ${finalTotal.toInt()})", fontWeight = FontWeight.Black, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun PaymentOptionRow(
    title: String,
    desc: String,
    selected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) ZaikaTealLight.copy(alpha = 0.5f) else ZaikaSlateLight
        ),
        border = if (selected) androidx.compose.foundation.BorderStroke(1.5.dp, ZaikaTeal) else null
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RadioButton(
                selected = selected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(selectedColor = ZaikaTeal)
            )
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ZaikaCharcoal)
                Text(desc, fontSize = 10.sp, color = ZaikaSlateMedium)
            }
        }
    }
}
