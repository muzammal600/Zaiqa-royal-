package com.zaikaroyale.app.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Order
import com.zaikaroyale.app.data.model.OrderStatus
import com.zaikaroyale.app.ui.components.StatusBadge
import com.zaikaroyale.app.ui.theme.*

@Composable
fun AdminOrdersScreen(
    orders: List<Order>,
    onUpdateStatus: (String, OrderStatus, String?) -> Unit,
    onBack: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf<OrderStatus?>(null) }
    var cancelDialogOrder by remember { mutableStateOf<Order?>(null) }
    var cancelReasonInput by remember { mutableStateOf("Item out of stock / Delivery address out of range") }

    val filteredOrders = orders.filter { order ->
        selectedFilter == null || order.status == selectedFilter
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        "Order Management & Kitchen Queue",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = ZaikaCharcoal
                    )
                    Text("${orders.size} total incoming customer orders", fontSize = 11.sp, color = ZaikaSlateMedium)
                }
            }
        }

        // Filter Pills
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item {
                    FilterChip(
                        selected = selectedFilter == null,
                        onClick = { selectedFilter = null },
                        label = { Text("All (${orders.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                }
                OrderStatus.values().forEach { status ->
                    val count = orders.count { it.status == status }
                    item {
                        FilterChip(
                            selected = selectedFilter == status,
                            onClick = { selectedFilter = status },
                            label = { Text("${status.displayName} ($count)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }
        }

        items(filteredOrders) { order ->
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ORDER #${order.orderNumber}", fontWeight = FontWeight.Black, fontSize = 14.sp)
                            Text("Time: ${order.createdAt}", fontSize = 10.sp, color = ZaikaSlateMedium)
                        }
                        StatusBadge(status = order.status)
                    }

                    HorizontalDivider()

                    Text("Customer: ${order.customerName} (${order.customerPhone})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Text("Area: ${order.deliveryArea} • Address: ${order.deliveryAddress}", fontSize = 11.sp, color = ZaikaSlateDark)

                    if (order.orderNotes != null) {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Note: \"${order.orderNotes}\"", fontSize = 11.sp, color = Color(0xFF92400E), modifier = Modifier.padding(8.dp))
                        }
                    }

                    // Itemized summary
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        order.items.forEach { item ->
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${item.quantity}x ${item.name}", fontSize = 11.sp, color = ZaikaCharcoal)
                                Text("Rs. ${item.subtotal.toInt()}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total (${order.paymentMethod.displayName})", fontWeight = FontWeight.Black, fontSize = 13.sp)
                        Text("Rs. ${order.totalAmount.toInt()}", fontWeight = FontWeight.Black, fontSize = 14.sp, color = ZaikaRed)
                    }

                    // Status Transition Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        when (order.status) {
                            OrderStatus.Pending -> {
                                Button(
                                    onClick = { onUpdateStatus(order.id, OrderStatus.Confirmed, null) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaTeal),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Accept & Confirm", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { cancelDialogOrder = order },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Reject", color = ZaikaRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            OrderStatus.Confirmed -> {
                                Button(
                                    onClick = { onUpdateStatus(order.id, OrderStatus.Preparing, null) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PurpleAccent),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Start Cooking", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            OrderStatus.Preparing -> {
                                Button(
                                    onClick = { onUpdateStatus(order.id, OrderStatus.OutForDelivery, null) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Dispatch to Rider", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            OrderStatus.OutForDelivery -> {
                                Button(
                                    onClick = { onUpdateStatus(order.id, OrderStatus.Delivered, null) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaGreen),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Mark as Delivered", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            else -> {}
                        }
                    }
                }
            }
        }
    }

    // Cancel Order Dialog
    cancelDialogOrder?.let { order ->
        AlertDialog(
            onDismissRequest = { cancelDialogOrder = null },
            title = { Text("Reject Order #${order.orderNumber}", fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Provide a cancellation reason for the customer:")
                    OutlinedTextField(
                        value = cancelReasonInput,
                        onValueChange = { cancelReasonInput = it },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateStatus(order.id, OrderStatus.Cancelled, cancelReasonInput)
                        cancelDialogOrder = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed)
                ) {
                    Text("Cancel Order")
                }
            },
            dismissButton = {
                TextButton(onClick = { cancelDialogOrder = null }) {
                    Text("Go Back")
                }
            }
        )
    }
}
