package com.zaikaroyale.app.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaikaroyale.app.data.model.Offer
import com.zaikaroyale.app.ui.theme.*

@Composable
fun AdminOffersScreen(
    offers: List<Offer>,
    onAddOffer: (Offer) -> Unit,
    onUpdateOffer: (Offer) -> Unit,
    onDeleteOffer: (String) -> Unit,
    onBack: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ZaikaBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text("Offers & Promo Deals", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = ZaikaCharcoal)
                        Text("${offers.size} coupons & promotions", fontSize = 11.sp, color = ZaikaSlateMedium)
                    }
                }

                Button(
                    onClick = { showDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Offer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        items(offers) { offer ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(offer.code, fontWeight = FontWeight.Black, fontSize = 14.sp, color = ZaikaCharcoal)
                            Surface(
                                color = if (offer.isActive) ZaikaGreen.copy(alpha = 0.15f) else ZaikaSlateLight,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    if (offer.isActive) "ACTIVE" else "INACTIVE",
                                    color = if (offer.isActive) ZaikaGreen else ZaikaSlateMedium,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(offer.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = ZaikaSlateDark)
                        Text("Min: Rs. ${offer.minOrderAmount.toInt()} • Discount: ${offer.discountValue.toInt()}${if (offer.discountType == "percentage") "%" else " Rs"}", fontSize = 11.sp, color = ZaikaTealDark)
                    }

                    Row {
                        Switch(
                            checked = offer.isActive,
                            onCheckedChange = { onUpdateOffer(offer.copy(isActive = it)) }
                        )
                        IconButton(onClick = { onDeleteOffer(offer.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ZaikaRed)
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        var code by remember { mutableStateOf("") }
        var title by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var discountVal by remember { mutableStateOf("20") }
        var minSpend by remember { mutableStateOf("1500") }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("New Promo Offer", fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = code, onValueChange = { code = it.uppercase() }, label = { Text("Code (e.g. FEAST25)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = discountVal, onValueChange = { discountVal = it }, label = { Text("Discount %") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = minSpend, onValueChange = { minSpend = it }, label = { Text("Min Order") }, modifier = Modifier.weight(1f))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (code.isNotBlank() && title.isNotBlank()) {
                            val off = Offer(
                                id = "off-${System.currentTimeMillis()}",
                                title = title,
                                description = desc,
                                code = code,
                                discountType = "percentage",
                                discountValue = discountVal.toDoubleOrNull() ?: 20.0,
                                minOrderAmount = minSpend.toDoubleOrNull() ?: 1500.0,
                                isActive = true
                            )
                            onAddOffer(off)
                            showDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ZaikaRed)
                ) {
                    Text("Create Offer")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancel") }
            }
        )
    }
}
