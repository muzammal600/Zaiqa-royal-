# Zaika Royale Proguard rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.zaikaroyale.app.data.model.** { *; }
